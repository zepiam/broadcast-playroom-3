from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define

T = TypeVar("T", bound="WebcastLiveAnalyticsUserInteractionsResponsePayGrade")


@_attrs_define
class WebcastLiveAnalyticsUserInteractionsResponsePayGrade:
    """
    Attributes:
        grade_banner (str):
        grade_describe (str):
        grade_icon_list (list[Any]):
        level (float):
        name (str):
        next_name (str):
        next_privileges (str):
        score (float):
        screen_chat_type (float):
        upgrade_need_consume (float):
    """

    grade_banner: str
    grade_describe: str
    grade_icon_list: list[Any]
    level: float
    name: str
    next_name: str
    next_privileges: str
    score: float
    screen_chat_type: float
    upgrade_need_consume: float

    def to_dict(self) -> dict[str, Any]:
        grade_banner = self.grade_banner

        grade_describe = self.grade_describe

        grade_icon_list = self.grade_icon_list

        level = self.level

        name = self.name

        next_name = self.next_name

        next_privileges = self.next_privileges

        score = self.score

        screen_chat_type = self.screen_chat_type

        upgrade_need_consume = self.upgrade_need_consume

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "grade_banner": grade_banner,
                "grade_describe": grade_describe,
                "grade_icon_list": grade_icon_list,
                "level": level,
                "name": name,
                "next_name": next_name,
                "next_privileges": next_privileges,
                "score": score,
                "screen_chat_type": screen_chat_type,
                "upgrade_need_consume": upgrade_need_consume,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        grade_banner = d.pop("grade_banner")

        grade_describe = d.pop("grade_describe")

        grade_icon_list = cast(list[Any], d.pop("grade_icon_list"))

        level = d.pop("level")

        name = d.pop("name")

        next_name = d.pop("next_name")

        next_privileges = d.pop("next_privileges")

        score = d.pop("score")

        screen_chat_type = d.pop("screen_chat_type")

        upgrade_need_consume = d.pop("upgrade_need_consume")

        webcast_live_analytics_user_interactions_response_pay_grade = cls(
            grade_banner=grade_banner,
            grade_describe=grade_describe,
            grade_icon_list=grade_icon_list,
            level=level,
            name=name,
            next_name=next_name,
            next_privileges=next_privileges,
            score=score,
            screen_chat_type=screen_chat_type,
            upgrade_need_consume=upgrade_need_consume,
        )

        return webcast_live_analytics_user_interactions_response_pay_grade
