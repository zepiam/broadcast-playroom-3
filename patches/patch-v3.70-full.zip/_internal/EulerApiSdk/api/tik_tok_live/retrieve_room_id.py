from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.webcast_room_id_route_response import WebcastRoomIdRouteResponse
from ...types import UNSET, Response


def _get_kwargs(
    *,
    unique_id: str,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["uniqueId"] = unique_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/webcast/room_id",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> WebcastRoomIdRouteResponse | None:
    if response.status_code == 200:
        response_200 = WebcastRoomIdRouteResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[WebcastRoomIdRouteResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    unique_id: str,
) -> Response[WebcastRoomIdRouteResponse]:
    """Requires Business Plan - Fetch Room ID for a given uniqueId & whether that user is live.

    Args:
        unique_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[WebcastRoomIdRouteResponse]
    """

    kwargs = _get_kwargs(
        unique_id=unique_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    unique_id: str,
) -> WebcastRoomIdRouteResponse | None:
    """Requires Business Plan - Fetch Room ID for a given uniqueId & whether that user is live.

    Args:
        unique_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        WebcastRoomIdRouteResponse
    """

    return sync_detailed(
        client=client,
        unique_id=unique_id,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    unique_id: str,
) -> Response[WebcastRoomIdRouteResponse]:
    """Requires Business Plan - Fetch Room ID for a given uniqueId & whether that user is live.

    Args:
        unique_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[WebcastRoomIdRouteResponse]
    """

    kwargs = _get_kwargs(
        unique_id=unique_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    unique_id: str,
) -> WebcastRoomIdRouteResponse | None:
    """Requires Business Plan - Fetch Room ID for a given uniqueId & whether that user is live.

    Args:
        unique_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        WebcastRoomIdRouteResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            unique_id=unique_id,
        )
    ).parsed
