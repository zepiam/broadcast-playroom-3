import logging
from typing import Any, AsyncIterator, Dict, Optional, Tuple, TypeAlias, Union

import httpx
from python_socks import parse_proxy_url
from websockets.exceptions import InvalidStatusCode  # type: ignore[attr-defined]
from websockets.legacy.client import Connect, WebSocketClientProtocol
from websockets_proxy import websockets_proxy
from websockets_proxy.websockets_proxy import ProxyConnect

from TikTokLive.client.errors import WebcastBlockedError
from TikTokLive.client.ws.ws_utils import extract_webcast_response_message, build_webcast_uri, extract_websocket_options
from TikTokLive.proto import ProtoMessageFetchResult, WebcastPushFrame

"""Type hint for a WebcastProxy, which can be either an HTTPX Proxy or a Websockets Proxy"""
WebcastProxy: TypeAlias = Union[httpx.Proxy, websockets_proxy.Proxy]

"""
Type hint for a WebcastIterator, which yields a tuple of WebcastPushFrame and ProtoMessageFetchResult.
WebcastPushFrame is Optional because the first yielded item is from the initial response
which is from /im/fetch (from the sign server), so it is not encapsulated by a WebcastPushFrame.
"""
WebcastIterator: TypeAlias = AsyncIterator[Tuple[Optional[WebcastPushFrame], ProtoMessageFetchResult]]


class WebcastConnect(Connect):

    def __init__(
            self,
            initial_webcast_response: ProtoMessageFetchResult,
            logger: logging.Logger,
            base_uri_params: Dict[str, Any],
            base_uri_append_str: str,
            uri: Optional[str] = None,
            **kwargs
    ):

        # If uri is provided (it should normally never be), bypass the construction
        if uri is None:
            uri = build_webcast_uri(
                initial_webcast_response=initial_webcast_response,
                base_uri_params=base_uri_params,
                base_uri_append_str=base_uri_append_str
            )

        super().__init__(uri, logger=logger, **kwargs)
        self.logger = self._logger = logger
        self.logger.debug(f"Built Webcast URI: {uri}")
        self._ws: Optional[WebSocketClientProtocol] = None
        self._ws_options: Optional[dict[str, str]] = None
        self._initial_response: ProtoMessageFetchResult = initial_webcast_response

    @property
    def ws(self) -> Optional[WebSocketClientProtocol]:
        """Get the current WebSocketClientProtocol"""

        return self._ws

    @property
    def ws_options(self) -> Optional[dict[str, str]]:
        """Get the WebSocket options as returned via the Handshake-Options header"""

        return self._ws_options

    # Liskov override: parent yields ``WebSocketClientProtocol`` instances; we
    # wrap the websocket and yield parsed ``(WebcastPushFrame, ProtoMessageFetchResult)``
    # tuples. The shape divergence is intentional — this iterator is the public
    # event stream, not a passthrough of the underlying socket.
    async def __aiter__(self) -> WebcastIterator:  # type: ignore[override]
        """
        Note as of Jul 6, 2025

        - This is a custom implementation over the default iterator
        - It disables retry mechanisms and **disallows** reconnects, since signed URLs expire after 30 seconds
        - Also, the default mechanism by the websockets library ignores the '200' error code and retries, even though this is a 'detected by TikTok' error & thus
          retrying is useless.

        tl;dr This goes from an iterator of WebSockets -> an iterator of Events

        """

        try:

            # "async with" yields a WebsocketClientProtocol
            # The connection happens in the "async with", so if you enter the loop, that means it connected to the WebSocket
            async with self as protocol:
                self._ws = protocol
                self._ws_options = extract_websocket_options(self._ws.response_headers)

                # Yield the first ProtoMessageFetchResult
                yield None, self._initial_response

                # "async for" yields "WebcastPushFrame" payloads as unparsed bytes
                async for payload_bytes in protocol:

                    # websockets returns ``str | bytes``; betterproto's parse only
                    # accepts bytes, so coerce strings up-front.
                    if isinstance(payload_bytes, str):
                        payload_bytes = payload_bytes.encode()

                    # Extract push frame
                    webcast_push_frame: WebcastPushFrame = WebcastPushFrame().parse(payload_bytes)

                    # Only ``msg`` frames carry the event stream. Everything
                    # else (``hb`` server heartbeat, ``ack`` receipt signal,
                    # ``im_enter_room_resp`` room-switch ack, etc.) is
                    # transport-level and intentionally discarded — matching
                    # how the JS connector handles them. Log at DEBUG for
                    # visibility, no parse attempt.
                    if webcast_push_frame.payload_type != "msg":
                        self._logger.debug(
                            "Discarded non-msg push frame (type=%r, len=%d)",
                            webcast_push_frame.payload_type,
                            len(webcast_push_frame.payload),
                        )
                        continue

                    # If it is of type msg, we can extract the ProtoMessageFetchResult item within
                    webcast_response: ProtoMessageFetchResult = extract_webcast_response_message(webcast_push_frame,
                                                                                                 logger=self._logger)
                    yield webcast_push_frame, webcast_response

        except InvalidStatusCode as ex:
            if ex.status_code == 400:
                raise WebcastBlockedError(
                    f"WebSocket rejected by TikTok due to \"400 Bad Request\" with reason \"{ex.headers.get('Handshake-Msg', 'an unknown reason')}\""
                ) from ex

            if ex.status_code == 200:
                # Note from Isaac post-insanity...
                # IF the WebSockets are >>SIGNED<< WITH A SESSION ID
                # and you DO NOT pass a sessionid cookie in the header, it will reject for "illegal secret key"
                raise WebcastBlockedError(
                    f"WebSocket rejected by TikTok due to \"{ex.headers.get('Handshake-Msg', 'an unknown reason')}\"."
                ) from ex
            raise

        finally:
            self._ws = None
            self._ws_options = None


class WebcastProxyConnect(WebcastConnect, ProxyConnect):
    """
    Add Proxy support to the WebcastConnect class

    """

    def __init__(
            self,
            proxy: Optional[WebcastProxy],
            **kwargs
    ):
        super().__init__(
            proxy=self._convert_proxy(proxy) if isinstance(proxy, httpx.Proxy) else proxy,
            **kwargs
        )

    @classmethod
    def _convert_proxy(cls, proxy: httpx.Proxy) -> websockets_proxy.Proxy:
        """Convert an HTTPX proxy to a websockets_proxy Proxy"""
        parsed: list = list(parse_proxy_url(str(proxy.url)))

        # Add auth back if the source proxy carried any
        if proxy.auth is not None:
            parsed[3] = proxy.auth[0]
            parsed[4] = proxy.auth[1]

        return websockets_proxy.Proxy(*parsed)
