import webbrowser
_orig_webbrowser_open = webbrowser.open

def _safe_webbrowser_open(url, *args, **kwargs):
    if not url or str(url).startswith('about:'):
        return False
    return _orig_webbrowser_open(url, *args, **kwargs)

webbrowser.open = _safe_webbrowser_open
import os

# Prevent background throttling in WebView2 / Chromium when gaming or minimized
_BG_THROTTLE_FLAGS = (
    "--disable-background-timer-throttling "
    "--disable-backgrounding-occluded-windows "
    "--disable-renderer-backgrounding "
    "--disable-features=CalculateNativeWinOcclusion,IntensiveWakeUpThrottling,QuickIntensiveWakeUpThrottlingAfterLoading "
    "--disable-http-cache "
    "--disable-application-cache"
)
_wv_existing = os.environ.get("WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS", "")
if "--disable-background-timer-throttling" not in _wv_existing:
    os.environ["WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS"] = (_wv_existing + " " + _BG_THROTTLE_FLAGS).strip()








import sys















if any(flag in sys.argv for flag in ("--repair", "--update", "--findupdate")):
    from findupdate import run_findupdate_cli
    sys.exit(run_findupdate_cli(force_repair="--repair" in sys.argv))

if "--splash-subprocess" in sys.argv:







    from splash import run_splash_subprocess







    sys.exit(run_splash_subprocess())























# Ensure UTF-8 output on Windows consoles







if hasattr(sys.stdout, 'reconfigure'):







    sys.stdout.reconfigure(encoding='utf-8', errors='replace')







if hasattr(sys.stderr, 'reconfigure'):







    sys.stderr.reconfigure(encoding='utf-8', errors='replace')















import subprocess







import logging







import collections







import threading







import time















class _LogCapture:







    def __init__(self, max_entries=2000):







        self.buffer = collections.deque(maxlen=max_entries)







        self.lock = threading.Lock()







        self.stdout_orig = sys.stdout







        self.stderr_orig = sys.stderr















    def write(self, s):







        if s:







            with self.lock:







                self.buffer.append((time.time(), s))







        if self.stdout_orig:







            try:







                self.stdout_orig.write(s)







                self.stdout_orig.flush()







            except Exception:







                pass















    def flush(self):







        if self.stdout_orig:







            try:







                self.stdout_orig.flush()







            except Exception:







                pass















    def get_logs(self, since=0.0):







        with self.lock:







            return [{'time': t, 'text': msg} for t, msg in self.buffer if t > since]















    def clear(self):







        with self.lock:







            self.buffer.clear()















log_capture = _LogCapture()







sys.stdout = log_capture







sys.stderr = log_capture







import tempfile







from pathlib import Path







from http.server import SimpleHTTPRequestHandler, HTTPServer, ThreadingHTTPServer







import socket







import webbrowser







import json







import urllib.parse







import urllib.request







import hashlib







from overlay_events import overlay_events







from app_presence import app_presence







from layout_migration import normalize_layout







from legacy_media import find_media, serve_media







from rvc_service import rvc_service







from now_playing_service import now_playing_service







from donation_goal_service import donation_goal_service







from avatar_mic_service import avatar_mic_service







from playroom_media import playroom_media







from emote_service import EmoteService







emote_service=EmoteService()







from legacy_chat_config import build_chat_config, build_global_chat_config, build_game_chat_config







from legacy_compat import start_servers as start_legacy_servers







from chat_bridge import chat_bridge







from dictionary_manager import dict_manager







from tts_service import tts_service







from updater import check_for_update, get_current_version, get_build_type, perform_update_and_restart, get_update_runtime_status, start_background_download, apply_pending_update_on_startup, restart_and_apply_update







from defender_helper import DefenderExclusionManager















PORT = 8801







_GLOBAL_SPLASH_CTRL = None















def close_splash():







    global _GLOBAL_SPLASH_CTRL







    if _GLOBAL_SPLASH_CTRL:







        try:







            _GLOBAL_SPLASH_CTRL.finish()







        except Exception:







            pass







        _GLOBAL_SPLASH_CTRL = None







LEGACY_STATUS = []







LEGACY_FILTER_IMPORT_ENABLED = False







GAME_CHAT_LOCK = threading.RLock()







DIST_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), 'dist'))

def ensure_frontend_integrity():
    """Runtime Self-Healing: If dist/index.html ever loses critical stylesheets or constraints,
    automatically patch it before pywebview loads it. This guarantees zero white-screen or giant-icon bugs."""
    try:
        idx_path = os.path.join(DIST_DIR, 'index.html')
        if not os.path.exists(idx_path):
            return
        with open(idx_path, 'r', encoding='utf-8') as f:
            content = f.read()

        repaired = False
        # 1. Guarantee inline styling for titlebar icon
        if '.desktop-titlebar-icon' in content and 'width:16px!important' not in content:
            content = content.replace(
                '<img src="./assets/bp-full-icon.png" class="desktop-titlebar-icon"',
                '<img src="./assets/bp-full-icon.png" class="desktop-titlebar-icon" style="width:16px!important;height:16px!important;max-width:16px!important;max-height:16px!important;object-fit:contain;flex-shrink:0;display:inline-block;"'
            )
            repaired = True

        # 2. Guarantee styles.css is loaded
        if 'styles.css' not in content and '</head>' in content:
            content = content.replace('</head>', '  <link rel="stylesheet" href="./styles.css">\n  <link rel="stylesheet" href="./modal.css">\n  <link rel="stylesheet" href="./ui_readability.css">\n</head>')
            repaired = True

        # 3. Guarantee dark background on html tag
        if '<html lang="th" class="notranslate" translate="no">' in content:
            content = content.replace('<html lang="th" class="notranslate" translate="no">', '<html lang="th" class="notranslate" translate="no" style="background:#1e1f22!important;color:#f2f3f5!important;">')
            repaired = True

        if repaired:
            with open(idx_path, 'w', encoding='utf-8') as f:
                f.write(content)
            logger.info("[INTEGRITY] Successfully self-healed frontend dist/index.html")
    except Exception as e:
        logger.warning(f"[INTEGRITY] Frontend check warning: {e}")

ensure_frontend_integrity()








SRC_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), 'src'))







_APP_ROOT = os.path.abspath(os.path.dirname(__file__))

ROOT_DIR = _APP_ROOT







_PARENT_DIR = os.path.dirname(_APP_ROOT)







_SHARED_DATA = os.path.join(_PARENT_DIR, 'data')







_LOCAL_DATA = os.path.join(_APP_ROOT, 'data')







_LOCAL_USERDATA = os.path.join(_APP_ROOT, 'userdata')







_PORTABLE_MARKER = os.path.join(_APP_ROOT, '.portable')







_PARENT_PORTABLE = os.path.join(_PARENT_DIR, '.portable')















# Resolution priority:







# 1. ../data/ (Shared data directory in root folder for full/ and lite/)







# 2. ./.portable or ./data/ or ./userdata/ (Direct portable mode)







# 3. %LOCALAPPDATA%\BroadcastPlayroom3 (Standard system user profile fallback)







if os.path.exists(_SHARED_DATA) or os.path.exists(_PARENT_PORTABLE):







    DATA_ROOT = Path(_SHARED_DATA)







    DATA_ROOT.mkdir(parents=True, exist_ok=True)







elif os.path.exists(_LOCAL_DATA):







    DATA_ROOT = Path(_LOCAL_DATA)







    DATA_ROOT.mkdir(parents=True, exist_ok=True)







elif os.path.exists(_LOCAL_USERDATA) or os.path.exists(_PORTABLE_MARKER) or os.environ.get('BP3_PORTABLE') == '1':







    DATA_ROOT = Path(_LOCAL_USERDATA)







    DATA_ROOT.mkdir(parents=True, exist_ok=True)







else:







    DATA_ROOT = Path(os.environ.get('LOCALAPPDATA') or Path.home() / 'AppData' / 'Local') / 'BroadcastPlayroom3'
















def _get_platform_settings_paths():
    paths = []
    try:
        paths.append(Path(DATA_ROOT) / 'platform_settings.json')
    except Exception:
        pass
    try:
        lad = os.environ.get('LOCALAPPDATA', '') or str(Path.home() / 'AppData' / 'Local')
        paths.append(Path(lad) / 'BroadcastPlayroom3' / 'platform_settings.json')
        paths.append(Path(lad) / 'BroadcastPlayroom3' / 'settings_backup' / 'platform_settings.json')
    except Exception:
        pass
    try:
        if '_SHARED_DATA' in globals() and _SHARED_DATA:
            paths.append(Path(_SHARED_DATA) / 'platform_settings.json')
    except Exception:
        pass
    try:
        if '_APP_ROOT' in globals() and _APP_ROOT:
            paths.append(Path(_APP_ROOT) / 'data' / 'platform_settings.json')
    except Exception:
        pass
    seen = set()
    res = []
    for pt in paths:
        s = str(pt.resolve()) if pt.exists() else str(pt)
        if s not in seen:
            seen.add(s)
            res.append(pt)
    return res

def _load_platform_settings():
    merged = {}
    candidates = []
    for pt in _get_platform_settings_paths():
        if pt.is_file() and pt.stat().st_size > 0:
            candidates.append(pt)
    try:
        candidates.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    except Exception:
        pass
    for pt in candidates:
        try:
            with open(pt, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if isinstance(data, dict):
                for k, v in data.items():
                    if k.startswith('channel_'):
                        if v and str(v).strip():
                            if k not in merged or not merged[k]:
                                merged[k] = str(v).strip()
                    elif k.startswith('auto_connect_'):
                        if k not in merged:
                            merged[k] = bool(v)
                    elif k == 'hidden_platforms':
                        if isinstance(v, list) and v:
                            if 'hidden_platforms' not in merged or not merged['hidden_platforms']:
                                merged['hidden_platforms'] = v
                        elif 'hidden_platforms' not in merged:
                            merged['hidden_platforms'] = v
                    elif k not in merged:
                        merged[k] = v
        except Exception:
            pass
    if merged:
        for pt in _get_platform_settings_paths():
            try:
                pt.parent.mkdir(parents=True, exist_ok=True)
                with open(pt, 'w', encoding='utf-8') as f:
                    json.dump(merged, f, ensure_ascii=False, indent=2)
            except Exception:
                pass
    return merged

def _save_platform_settings(new_data):
    if not isinstance(new_data, dict):
        return
    current = _load_platform_settings()
    for k, v in new_data.items():
        if k.startswith('channel_'):
            if v and str(v).strip():
                current[k] = str(v).strip()
            elif new_data.get('explicit_clear') or new_data.get('allow_empty'):
                current[k] = ''
        elif k.startswith('auto_connect_'):
            if isinstance(v, bool):
                current[k] = v
            elif str(v).lower() in ('true', 'false'):
                current[k] = str(v).lower() == 'true'
        elif k == 'hidden_platforms':
            if isinstance(v, list):
                current['hidden_platforms'] = v
        else:
            current[k] = v
    for pt in _get_platform_settings_paths():
        try:
            pt.parent.mkdir(parents=True, exist_ok=True)
            with open(pt, 'w', encoding='utf-8') as f:
                json.dump(current, f, ensure_ascii=False, indent=2)
        except Exception:
            pass
    try:
        lad = os.environ.get('LOCALAPPDATA', '') or str(Path.home() / 'AppData' / 'Local')
        bak = Path(lad) / 'BroadcastPlayroom3' / 'settings_backup' / 'platform_settings.json'
        bak.parent.mkdir(parents=True, exist_ok=True)
        with open(bak, 'w', encoding='utf-8') as f:
            json.dump(current, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

def _get_user_roster_paths():
    paths = []
    try:
        paths.append(Path(DATA_ROOT) / 'user_roster.json')
    except Exception:
        pass
    try:
        lad = os.environ.get('LOCALAPPDATA', '') or str(Path.home() / 'AppData' / 'Local')
        paths.append(Path(lad) / 'BroadcastPlayroom3' / 'user_roster.json')
        paths.append(Path(lad) / 'BroadcastPlayroom3' / 'settings_backup' / 'user_roster.json')
    except Exception:
        pass
    try:
        if '_SHARED_DATA' in globals() and _SHARED_DATA:
            paths.append(Path(_SHARED_DATA) / 'user_roster.json')
    except Exception:
        pass
    try:
        if '_APP_ROOT' in globals() and _APP_ROOT:
            paths.append(Path(_APP_ROOT) / 'data' / 'user_roster.json')
    except Exception:
        pass
    seen = set()
    res = []
    for pt in paths:
        s = str(pt.resolve()) if pt.exists() else str(pt)
        if s not in seen:
            seen.add(s)
            res.append(pt)
    return res

def _merge_user_rosters(base_list, incoming_list):
    """ผสานรายชื่อผู้ชม รายละเอียดประวัติ และกิจกรรมเข้าด้วยกัน ป้องกันการสูญหายข้ามโฟลเดอร์/อัปเดต"""
    merged = {}
    for item in (base_list or []) + (incoming_list or []):
        if not isinstance(item, dict):
            continue
        u = str(item.get('username') or item.get('name') or '').strip()
        if not u:
            continue
        plat = str(item.get('platform') or 'Twitch').strip()
        k = f"{plat}:{u}".lower()
        if k not in merged:
            merged[k] = dict(item)
            merged[k]['username'] = u
            merged[k]['platform'] = plat
        else:
            cur = merged[k]
            cur['count'] = max(int(cur.get('count') or 0), int(item.get('count') or 0))
            cur['joinCount'] = max(int(cur.get('joinCount') or 0), int(item.get('joinCount') or 0))
            cur['lastSeen'] = max(int(cur.get('lastSeen') or 0), int(item.get('lastSeen') or 0))
            cur['isVip'] = bool(cur.get('isVip') or item.get('isVip'))
            if not cur.get('avatar') and item.get('avatar'):
                cur['avatar'] = item['avatar']
            if not cur.get('nickname') and item.get('nickname'):
                cur['nickname'] = item['nickname']
            # merge history
            h_combined = (cur.get('history') or []) + (item.get('history') or [])
            h_seen = set()
            h_unique = []
            for h in h_combined:
                if isinstance(h, dict):
                    hk = (h.get('time'), str(h.get('text') or '').strip())
                    if hk not in h_seen:
                        h_seen.add(hk)
                        h_unique.append(h)
            h_unique.sort(key=lambda x: x.get('time') or 0)
            cur['history'] = h_unique[-250:]
            # merge events
            ev_combined = (cur.get('events') or []) + (item.get('events') or [])
            ev_seen = set()
            ev_unique = []
            for ev in ev_combined:
                if isinstance(ev, dict):
                    evk = (ev.get('time'), ev.get('event'), str(ev.get('text') or '').strip())
                    if evk not in ev_seen:
                        ev_seen.add(evk)
                        ev_unique.append(ev)
            ev_unique.sort(key=lambda x: x.get('time') or 0)
            cur['events'] = ev_unique[-250:]
    return list(merged.values())

def _load_user_roster():
    merged_roster = []
    found_any = False
    for pt in _get_user_roster_paths():
        if pt.is_file() and pt.stat().st_size > 0:
            try:
                with open(pt, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                items = data.get('roster') if isinstance(data, dict) and isinstance(data.get('roster'), list) else data
                if isinstance(items, list) and len(items) > 0:
                    merged_roster = _merge_user_rosters(merged_roster, items)
                    found_any = True
            except Exception:
                pass
    # If merged roster has records, ensure all candidate paths are synced with the full merged roster
    if found_any and len(merged_roster) > 0:
        for pt in _get_user_roster_paths():
            try:
                if not pt.exists() or pt.stat().st_size <= 10:
                    pt.parent.mkdir(parents=True, exist_ok=True)
                    with open(pt, 'w', encoding='utf-8') as f:
                        json.dump(merged_roster, f, ensure_ascii=False, indent=2)
            except Exception:
                pass
    return merged_roster

def _save_user_roster(roster_data):
    if not isinstance(roster_data, list):
        return
    existing = _load_user_roster()
    # Guard against accidental wipe: if incoming is empty, preserve existing
    if len(roster_data) == 0:
        if len(existing) > 0:
            return
        to_save = []
    else:
        to_save = _merge_user_rosters(existing, roster_data)
        
    for pt in _get_user_roster_paths():
        try:
            pt.parent.mkdir(parents=True, exist_ok=True)
            tmp = pt.with_suffix('.tmp')
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(to_save, f, ensure_ascii=False, indent=2)
            tmp.replace(pt)
        except Exception:
            try:
                with open(pt, 'w', encoding='utf-8') as f:
                    json.dump(to_save, f, ensure_ascii=False, indent=2)
            except Exception:
                pass
    try:
        lad = os.environ.get('LOCALAPPDATA', '') or str(Path.home() / 'AppData' / 'Local')
        bak = Path(lad) / 'BroadcastPlayroom3' / 'settings_backup' / 'user_roster.json'
        bak.parent.mkdir(parents=True, exist_ok=True)
        tmp = bak.with_suffix('.tmp')
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(to_save, f, ensure_ascii=False, indent=2)
        tmp.replace(bak)
    except Exception:
        pass

_cand_layout = DATA_ROOT / 'composer_layout.json'







if not _cand_layout.exists() and os.path.exists(os.path.join(_APP_ROOT, 'composer_layout.json')):







    LAYOUT_FILE = os.path.abspath(os.path.join(_APP_ROOT, 'composer_layout.json'))







else:







    LAYOUT_FILE = os.path.abspath(os.path.join(os.environ.get('BP3_DATA_DIR', str(DATA_ROOT)), 'composer_layout.json'))















from bot_auth import BotAccounts







bot_account_dir = DATA_ROOT







from dns_settings import DnsSettings







dns_settings=DnsSettings(bot_account_dir / 'dns_settings.json')







tts_service.dns_settings=dns_settings







bot_accounts = BotAccounts(bot_account_dir / 'bot_accounts.dat', apply_account=chat_bridge.apply_bot_account)







chat_bridge.accounts = bot_accounts
try:
    from plugin_manager import plugin_manager
    plugin_manager.initialize(DATA_ROOT)
except Exception:
    pass
try:
    _saved_settings = _load_platform_settings()
    _saved_trans_mode = _saved_settings.get('translate_mode', 'translate')
    if _saved_trans_mode in ('translate', 'multilang'):
        chat_bridge.set_translate_mode(_saved_trans_mode)
except Exception:
    pass















_LAYOUT_CACHE = None







_LAYOUT_MTIME = 0















def get_layout():







    global _LAYOUT_CACHE, _LAYOUT_MTIME







    if os.path.exists(LAYOUT_FILE):







        try:







            mtime = os.path.getmtime(LAYOUT_FILE)







            if _LAYOUT_CACHE is None or mtime > _LAYOUT_MTIME:







                with open(LAYOUT_FILE, 'r', encoding='utf-8') as f:







                    _LAYOUT_CACHE = normalize_layout(json.load(f))







                    _LAYOUT_MTIME = mtime







                return _LAYOUT_CACHE







        except Exception:







            pass







    if _LAYOUT_CACHE is not None:







        return _LAYOUT_CACHE







    _LAYOUT_CACHE = {







        "pages": [







            {







                "id": "page-1",







                "name": "หน้า 1 (มาตรฐาน)",







                "widgets": [







                    {







                        "id": "w-chat-1",







                        "type": "chat",







                        "title": "แชทสด",







                        "x": 40,







                        "y": 500,







                        "width": 440,







                        "height": 520,







                        "z": 10,







                        "chatTheme": "glass-dark",







                        "chatMode": "default"







                    },







                    {







                        "id": "w-clock-1",







                        "type": "clock",







                        "title": "นาฬิกาดิจิทัล",







                        "x": 1640,







                        "y": 40,







                        "width": 240,







                        "height": 70,







                        "z": 11,







                        "clockTheme": "neon-glow",







                        "clockFormat": "HH:MM:SS"







                    }







                ]







            }







        ],







        "activePageId": "page-1",







        "updatedAt": time.time()







    }







    return _LAYOUT_CACHE















def save_layout(data):







    global _LAYOUT_CACHE, _LAYOUT_MTIME







    normalized = normalize_layout(data)







    # Replace atomically so OBS polling never reads half a JSON document.







    temporary = None







    try:







        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=os.path.dirname(LAYOUT_FILE), suffix='.json.tmp', delete=False) as stream:







            temporary = stream.name







            json.dump(normalized, stream, ensure_ascii=False, indent=2)







        os.replace(temporary, LAYOUT_FILE)







        _LAYOUT_CACHE = normalized







        _LAYOUT_MTIME = os.path.getmtime(LAYOUT_FILE)







    finally:







        if temporary and os.path.exists(temporary):







            os.remove(temporary)























from desktop_overlay_service import DesktopOverlays







desktop_overlays=DesktopOverlays(get_layout,save_layout,overlay_events.publish)















APP_PROJECT_ID=hashlib.sha256(os.path.normcase(os.path.realpath(os.path.dirname(__file__))).encode('utf-8')).hexdigest()







DOCK_STATE={}







from clip_markers import ClipMarkers







clip_markers = ClipMarkers(bot_account_dir / 'data')







from obs_connection import ObsConnection







obs_connection = ObsConnection(bot_account_dir / 'obs_connection.dat', clip_markers, source_ports=lambda: {PORT, *(item['port'] for item in LEGACY_STATUS if item.get('status')=='online')})







from clip_hotkey import ClipHotkey







clip_hotkey = ClipHotkey(bot_account_dir / 'clip_hotkey.json', clip_markers)







from legacy_secret_sounds import LegacySecretSounds







legacy_secret_sounds = LegacySecretSounds()















# In-memory LRU cache for TTS & RVC audio streams







_TTS_CACHE_LOCK = threading.Lock()







_TTS_AUDIO_CACHE = collections.OrderedDict()







_TTS_CACHE_MAX = 128
















_tool_popout_windows = {}
_window_close_lock = threading.Lock()
_closing_window_ids = set()

def safe_destroy_window(w):
    if not w:
        return False
    w_id = id(w)
    with _window_close_lock:
        if w_id in _closing_window_ids:
            return True
        _closing_window_ids.add(w_id)
    try:
        w.destroy()
        return True
    except Exception:
        return False

def normalize_tool_name(tool_name):
    name = (tool_name or '').strip().lower()
    aliases = {
        'voice': 'voice-settings',
        'voice-setting': 'voice-settings',
        'reply': 'replie',
        'replies': 'replie',
        'users': 'user-manager',
        'usermanager': 'user-manager',
        'user': 'user-manager',
        'random': 'randomizer',
        'overlay+': 'overlay-plus-settings',
        'overlayplus': 'overlay-plus-settings',
        'overlay-plus': 'overlay-plus-settings',
    }
    return aliases.get(name, name)

def handle_tool_popout(tool_name, main_url, section=None):
    name = normalize_tool_name(tool_name)
    if not name: return {'ok': False, 'error': 'empty tool'}
    
    global _tool_popout_windows
    if name in _tool_popout_windows:
        tw = _tool_popout_windows[name]
        try:
            tw.show()
            tw.restore()
            if section and name == 'settings':
                try:
                    tw.evaluate_js(f"try {{ (window.switchSettingsSection || switchSettingsSection)('{section}'); }} catch(e) {{}}")
                except Exception:
                    pass
            if name == 'author-profile':
                try:
                    tw.evaluate_js("try { if (window.syncAuthorProfile) window.syncAuthorProfile(); } catch(e) {}")
                except Exception:
                    pass
            return {'ok': True, 'focused': True}
        except Exception:
            _tool_popout_windows.pop(name, None)
            
    import webview
    titles = {
        'giveaway': 'Giveaway Tool สุ่มแจกรางวัล',
        'ask': 'ASK Widget ตั้งคำถามโหวต',
        'replie': 'Replie Tools ข้อความตอบกลับ',
        'randomizer': 'Quick Randomizer สุ่มชื่อ / เลข',
        'user-manager': 'จัดการผู้ชม (User Manager)',
        'settings': 'ตั้งค่าระบบ (Settings)',
        'voice-settings': 'ตั้งค่าเสียงอ่าน (Voice Settings)',
        'chat-widget': 'Chat Widget Customizer',
        'playroom': 'Playroom Studio ไลฟ์ซาวด์ & คลิปสั้น',
        'author-profile': 'โปรไฟล์ผู้ชม',
        'game-overlay': 'ตั้งค่า Game Overlay',
        'overlay-plus-settings': 'ตั้งค่า Overlay+ (เบราว์เซอร์ลอย)',
        'composer': 'Composer Studio จัดฉากถ่ายทอดสด'
    }
    sizes = {
        'composer': (1280, 860),
        'chat-settings': (760, 640),
        'settings': (940, 700),
        'user-manager': (880, 640),
        'voice-settings': (760, 790),
        'giveaway': (760, 600),
        'ask': (700, 580),
        'replie': (700, 560),
        'randomizer': (660, 540),
        'playroom': (840, 640),
        'chat-widget': (900, 680),
        'author-profile': (780, 800),
        'game-overlay': (760, 620),
        'overlay-plus-settings': (700, 480)
    }
    sz = sizes.get(name, (800, 600))
    title = titles.get(name, f'Broadcast Playroom - {name.capitalize()}')
    url = f"{main_url}/index.html?popout={name}"
    if section:
        url += f"&section={urllib.parse.quote(str(section))}"
    url += f"&_v={int(time.time() * 1000)}"
    
    class PopoutJsApi:
        def __init__(self, tool_name, win_ref=None):
            self.tool_name = tool_name
            self.win_ref = win_ref
        def close(self):
            target = self.win_ref or _tool_popout_windows.pop(self.tool_name, None)
            if self.tool_name in _tool_popout_windows:
                _tool_popout_windows.pop(self.tool_name, None)
            if target:
                threading.Thread(target=safe_destroy_window, args=(target,), daemon=True).start()
            return {'ok': True}

    if section and name == 'settings':
        url = url + f"&section={section}"

    api = PopoutJsApi(name)
    try:
        tw = webview.create_window(
            title=title,
            url=url,
            width=sz[0],
            height=sz[1],
            min_size=(480, 360),
            js_api=api
        )
    except Exception as e:
        print(f"[ERROR] Failed to create popout window for '{name}': {e}", flush=True)
        return {'ok': False, 'error': str(e)}
    api.win_ref = tw
    _tool_popout_windows[name] = tw
    def on_closed():
        _tool_popout_windows.pop(name, None)
    tw.events.closed += on_closed
    return {'ok': True, 'created': True}

class QuietHandler(SimpleHTTPRequestHandler):







    legacy_view = 'composer'







    def __init__(self, *args, **kwargs):







        super().__init__(*args, directory=DIST_DIR, **kwargs)

    def end_headers(self):
        # Force browser/WebView2 to never cache local assets so updates are 100% immediate
        buffer_str = b"".join(getattr(self, '_headers_buffer', [])).decode('latin1', errors='ignore')
        if 'cache-control' not in buffer_str.lower():
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0')
            self.send_header('Pragma', 'no-cache')
            self.send_header('Expires', '0')
        super().end_headers()















    def handle(self):







        try:







            super().handle()







        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):







            # Browser navigation cancels in-flight polling/media requests normally.







            return















    def log_message(self, format, *args):







        pass















    def send_cors_headers(self):







        self.send_header('Access-Control-Allow-Origin', '*')







        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')







        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Cache-Control, X-Filename')















    def do_OPTIONS(self):







        self.send_response(200)







        self.send_cors_headers()







        self.end_headers()















    def do_GET(self):







        parsed = urllib.parse.urlparse(self.path)







        path = parsed.path















        if path == '/api/avatars/cache-info':
            import avatar_cache_service
            info = avatar_cache_service.get_cache_info(DATA_ROOT)
            self.send_json(info)
            return

        if path == '/api/avatar/fetch':
            import avatar_cache_service
            query = urllib.parse.parse_qs(parsed.query)
            plat = query.get('platform', ['twitch'])[0]
            uname = query.get('username', [''])[0]
            img_data = avatar_cache_service.get_or_fetch_avatar(DATA_ROOT, plat, uname)
            if img_data:
                self.send_response(200)
                self.send_header('Content-Type', 'image/png')
                self.send_header('Content-Length', str(len(img_data)))
                self.send_header('Cache-Control', 'public, max-age=86400')
                self.end_headers()
                self.wfile.write(img_data)
            else:
                self.send_response(404)
                self.end_headers()
            return

        if path == '/api/splash/close':







            close_splash()







            self.send_json({'ok': True})







            return







        if path in ('/favicon.ico', '/favicon.png', '/api/app-icon'):







            ed = getattr(rvc_service, 'edition', 'full')







            if path == '/favicon.png':







                cand = [







                    os.path.join(DIST_DIR, 'assets', 'icon.png'),







                    os.path.join(DIST_DIR, 'assets', f'bp-{ed}-icon.png'),







                    os.path.join(SRC_DIR, 'assets', 'icon.png'),







                    os.path.join(ROOT_DIR, 'assets', 'icons', f'bp-{ed}-icon.png'),







                ]







                content_type = 'image/png'







            else:







                icon_file = 'bp-full-icon.ico' if ed == 'full' else 'bp-lite-icon.ico'







                cand = [







                    os.path.join(DIST_DIR, 'assets', 'icon.ico'),







                    os.path.join(DIST_DIR, 'assets', f'icon_{ed}.ico'),







                    os.path.join(ROOT_DIR, 'assets', 'icons', icon_file),







                    os.path.join(SRC_DIR, 'assets', f'icon_{ed}.ico'),







                    os.path.join(SRC_DIR, 'assets', 'icon.ico'),







                ]







                content_type = 'image/x-icon'







            for c_path in cand:







                if os.path.isfile(c_path):







                    try:







                        with open(c_path, 'rb') as f_ico:







                            ico_data = f_ico.read()







                        self.send_response(200)







                        self.send_header('Content-Type', content_type)







                        self.send_header('Content-Length', str(len(ico_data)))







                        self.send_header('Cache-Control', 'public, max-age=86400')







                        self.end_headers()







                        self.wfile.write(ico_data)







                        return







                    except Exception:







                        pass















        if path in ('/manifest.json', '/manifest.webmanifest'):







            manifest_candidates = [







                os.path.join(DIST_DIR, 'manifest.json'),







                os.path.join(ROOT_DIR, 'public', 'manifest.json'),







                os.path.join(SRC_DIR, 'manifest.json'),







            ]







            for m_path in manifest_candidates:







                if os.path.isfile(m_path):







                    try:







                        with open(m_path, 'rb') as f_man:







                            man_data = f_man.read()







                        self.send_response(200)







                        self.send_header('Content-Type', 'application/manifest+json; charset=utf-8')







                        self.send_header('Content-Length', str(len(man_data)))







                        self.send_header('Cache-Control', 'public, max-age=86400')







                        self.end_headers()







                        self.wfile.write(man_data)







                        return







                    except Exception:







                        pass























        if path == '/api/chatbot/auth/status':







            origin = self.headers.get('Origin')







            if origin:







                parsed_origin = urllib.parse.urlparse(origin)







                if parsed_origin.scheme != 'http' or parsed_origin.hostname not in ('localhost', '127.0.0.1') or parsed_origin.port != self.server.server_port:







                    self.send_json({'error':'Invalid origin'},403); return







            data = bot_accounts.public()







            with chat_bridge._lock:







                for platform, info in data.items():







                    client = chat_bridge._clients.get(platform)







                    info['ready'] = bool(client and getattr(client,'is_connected',False) and getattr(client,'can_send',False))







            self.send_json(data); return















        if path == '/api/legacy/secret-sounds':







            origin=self.headers.get('Origin')







            if origin:







                parsed_origin=urllib.parse.urlparse(origin)







                if parsed_origin.scheme!='http' or parsed_origin.hostname not in ('localhost','127.0.0.1') or parsed_origin.port!=self.server.server_port:







                    self.send_json({'error':'Invalid origin'},403);return







            self.send_json(legacy_secret_sounds.read() if LEGACY_FILTER_IMPORT_ENABLED else {'found':False,'entries':[]});return







        if path.startswith('/legacy-secret-sound/'):







            origin=self.headers.get('Origin')







            if origin:







                parsed_origin=urllib.parse.urlparse(origin)







                if parsed_origin.scheme!='http' or parsed_origin.hostname not in ('localhost','127.0.0.1') or parsed_origin.port!=self.server.server_port:







                    self.send_json({'error':'Invalid origin'},403);return







            ident=path.removeprefix('/legacy-secret-sound/')







            target=legacy_secret_sounds.find(ident)







            if target:serve_media(self,target)







            else:self.send_error(404)







            return















        if path == '/api/dns/settings':







            origin=self.headers.get('Origin')







            if origin:







                parsed_origin=urllib.parse.urlparse(origin)







                if parsed_origin.scheme!='http' or parsed_origin.hostname not in ('localhost','127.0.0.1') or parsed_origin.port!=self.server.server_port:







                    self.send_json({'error':'Invalid origin'},403);return







            self.send_json({**dns_settings.public(),'has_saved':dns_settings.path.exists()});return















        if path == '/api/legacy/user-filters':







            origin=self.headers.get('Origin')







            if origin:







                parsed_origin=urllib.parse.urlparse(origin)







                if parsed_origin.scheme!='http' or parsed_origin.hostname not in ('localhost','127.0.0.1') or parsed_origin.port!=self.server.server_port:







                    self.send_json({'error':'Invalid origin'},403);return







            if not LEGACY_FILTER_IMPORT_ENABLED:self.send_json({});return







            from legacy_user_filters import load







            self.send_json(load());return















        if path == '/api/stream-title':







            qs = urllib.parse.parse_qs(parsed.query)







            plat = qs.get('platform', [''])[0].lower()







            chan = qs.get('channel', [''])[0].strip()







            if not chan:







                with chat_bridge._lock:







                    chan = chat_bridge._statuses.get(plat, {}).get('target', '')







            title = chat_bridge.fetch_stream_title(plat, chan)







            with chat_bridge._lock:







                if plat in chat_bridge._statuses and title:







                    chat_bridge._statuses[plat]['title'] = title







            self.send_json({'ok': True, 'platform': plat, 'channel': chan, 'title': title})







            return















        if path == '/api/translate/mode':







            self.send_json({'ok': True, 'mode': chat_bridge.get_translate_mode()})







            return















        if path == '/api/clip-hotkey/status':







            origin=self.headers.get('Origin')







            if origin:







                parsed_origin=urllib.parse.urlparse(origin)







                if parsed_origin.scheme!='http' or parsed_origin.hostname not in ('localhost','127.0.0.1') or parsed_origin.port!=self.server.server_port:







                    self.send_json({'error':'Invalid origin'},403);return







            self.send_json({'active':False,'suspended':True});return















        if path == '/api/obs/status':







            origin=self.headers.get('Origin')







            if origin:







                parsed_origin=urllib.parse.urlparse(origin)







                if parsed_origin.scheme!='http' or parsed_origin.hostname not in ('localhost','127.0.0.1') or parsed_origin.port!=self.server.server_port:







                    self.send_json({'error':'Invalid origin'},403);return







            self.send_json(obs_connection.public()); return















        if path == '/api/supporters':







            from supporters_service import fetch







            self.send_json(fetch());return















        if path=='/api/app-instance':







            self.send_json({'application':'BroadcastPlayroom3','project':APP_PROJECT_ID,'edition':rvc_service.edition,'closing':app_presence.status()['closing']});return







        if path=='/api/app-presence':







            self.send_json(app_presence.status());return







        if path=='/api/app-presence/stream':







            close_splash()



            try:



                from app_window_frame import apply_icon_to_app_windows



                apply_icon_to_app_windows()



            except Exception:



                pass







            client=urllib.parse.parse_qs(parsed.query).get('client',[''])[0]







            if not client or len(client)>128:self.send_json({'error':'Invalid client'},400);return







            token=app_presence.open(client)







            if not token:self.send_json({'error':'Closed client'},410);return







            self.send_response(200);self.send_header('Content-Type','text/event-stream');self.send_header('Cache-Control','no-store');self.end_headers()







            self.connection.settimeout(3)







            try:







                while app_presence.touch(token):







                    self.wfile.write(b'data: ready\n\n');self.wfile.flush();time.sleep(1)







            except (OSError,TimeoutError):pass







            finally:app_presence.close(token)







            return















        if path=='/api/dock/status':







            layout=get_layout() or {};pages=layout.get('pages',[]);page=next((p for p in pages if p.get('id')==layout.get('activePageId')),pages[0] if pages else {})







            statuses=chat_bridge.get_status();counts={key:int(value.get('viewers') or 0) for key,value in statuses.items() if value.get('connected')}







            with overlay_events.lock:







                recent=[dict(item['payload'],id=item['payload'].get('id',item['id']),author=item['payload'].get('username',''),raw_author=item['payload'].get('username','')) for item in overlay_events.chat]







            state={**DOCK_STATE,'pages':[{'id':p.get('id'),'name':p.get('name',p.get('id'))} for p in pages],'active_page_id':page.get('id'),'active_widgets':[dict(w,enabled=not w.get('hidden',False),name=w.get('title',w['type'])) for w in page.get('widgets',[])],'viewers':{'total':sum(counts.values()),'platforms':counts},'recent_messages':recent,'widgets_installed':{kind:any(w.get('type')==kind for w in page.get('widgets',[])) for kind in ['chat','replie','ask','giveaway']}}







            from obs_scene_info import dock_scene







            obs_status=obs_connection.public();state['scene_overlay']=dock_scene(layout,obs_status['scene']);state['obs_stream']=obs_status['stream']







            self.send_json({'status':state});return







        if path=='/api/giveaway-settings':







            self.send_json(((get_layout() or {}).get('legacyTools') or {}).get('giveaway') or {});return







        if path=='/api/desktop-overlays':







            self.send_json({**desktop_overlays.snapshot(),'settings':{key:value for key,value in ((get_layout() or {}).get('legacyTools') or {}).items() if key=='more_overlays' or key.startswith('game_overlay_') or key.startswith('viewer_overlay_')}});return







        if path=='/api/game-chat-settings':







            from game_chat_settings import snapshot







            layout=get_layout() or {};settings={**(layout.get('legacyChat') or {}),**(layout.get('legacyTools') or {})}







            self.send_json(snapshot(settings));return







        if path=='/legacy-game-chat.html':







            self.serve_custom_file(os.path.join(DIST_DIR,'legacy_game_chat.html'),'text/html; charset=utf-8');return







        if path in ('/game-chat-config','/game-theme','/game-custom-css'):







            settings={**((get_layout() or {}).get('legacyChat') or {}),**((get_layout() or {}).get('legacyTools') or {})}







            config=build_game_chat_config(settings)







            if path=='/game-chat-config':self.send_json(config)







            else:







                data=config['theme_css' if path=='/game-theme' else 'custom_css'].encode('utf-8');self.send_response(200);self.send_header('Content-Type','text/css; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)







            return







        if path == '/legacy-chat.html':







            self.serve_custom_file(os.path.join(DIST_DIR,'legacy_chat.html'),'text/html; charset=utf-8')







            return







        if path in ('/chat-config','/config'):







            layout=get_layout() or {};settings=layout.get('legacyChat') or {};query=urllib.parse.parse_qs(parsed.query);wid=query.get('id',[''])[0]







            if path=='/config' or wid=='__global__':







                self.send_json(build_global_chat_config(settings));return







            else:







                pages=layout.get('pages',[]);page_value=query.get('p',[layout.get('activePageId','')])[0]







                selected=next((page for page in pages if str(page.get('id'))==page_value or str(page.get('name','')).lower()==str(page_value).lower()),None)







                if selected is None and str(page_value).isdigit() and 1<=int(page_value)<=len(pages):selected=pages[int(page_value)-1]







                candidates=selected.get('widgets',[]) if selected else [widget for page in pages for widget in page.get('widgets',[])]







                widget=next((widget for widget in candidates if str(widget.get('id'))==wid),{})







            self.send_json(build_chat_config(widget,settings))







            return







        if path.startswith(('/emote/','/game-emote/')):







            layout=get_layout() or {}







            if path.startswith('/game-emote/'):







                settings={**(layout.get('legacyChat') or {}),**(layout.get('legacyTools') or {})}







                animated=settings.get('game_overlay_animated_emotes',False)







            else:animated=(layout.get('legacyChat') or {}).get('overlay_animated_emotes',True)







            result=emote_service.read(urllib.parse.unquote(path.rsplit('/',1)[-1]),animated)







            if result is None:self.send_error(404)







            else:







                data,mime=result;self.send_response(200);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(data)));self.send_cors_headers();self.end_headers();self.wfile.write(data)







            return







        if path.startswith('/logo/'):















            platform=path.rsplit('/',1)[-1].lower()







            if platform in ('twitch','youtube','kick','tiktok','soop','mylive'):







                self.serve_custom_file(os.path.join(SRC_DIR,'assets',platform+'.png'),'image/png')







            else:self.send_error(404)







            return







        if path.startswith('/playroom-media/'):







            origin=self.headers.get('Origin')







            if origin:







                parsed_origin=urllib.parse.urlparse(origin)







                if parsed_origin.scheme!='http' or parsed_origin.hostname not in ('localhost','127.0.0.1') or parsed_origin.port!=self.server.server_port:







                    self.send_json({'error':'Invalid origin'},403);return







            media=playroom_media.find(path)







            if media is None:self.send_error(404)







            else:serve_media(self,media)







            return







        if path == '/api/avatar/sync':







            avatar_mic_service.sync(get_layout())







            self.send_json({'ok':True})







            return







        if path == '/api/donation-goals':







            donation_goal_service.sync(get_layout())







            self.send_json(donation_goal_service.snapshot())







            return







        if path in ('/api/now-playing', '/api/now-playing/thumbnail'):







            source = urllib.parse.parse_qs(parsed.query).get('source', ['auto'])[0]







            if path.endswith('/thumbnail'):







                target = now_playing_service.thumbnail(source)







                if target:







                    serve_media(self, target)







                else:







                    self.send_error(404)







            else:







                state = now_playing_service.snapshot(source)







                state['thumbnail'] = ('/api/now-playing/thumbnail?source=' + urllib.parse.quote(source)) if state['thumbnail'] else ''







                self.send_json(state)







            return







        if path == '/api/viewer-overlay':







            from viewer_overlay_config import snapshot







            self.send_json(snapshot(get_layout(),chat_bridge.get_status()));return







        if path == '/api/capabilities':







            self.send_json(rvc_service.capabilities())







            return







        if path.startswith('/api/rvc/'):







            try:







                if path == '/api/rvc/models':self.send_json({'models':rvc_service.public_models(),'status':rvc_service.status()})







                elif path == '/api/rvc/catalog':self.send_json({'models':rvc_service.public_catalog()})







                elif path == '/api/rvc/status':self.send_json(rvc_service.status())







                else:self.send_json({'error':'Unknown RVC endpoint'},404)







            except PermissionError as error:self.send_json({'error':str(error)},403)







            except Exception as error:self.send_json({'error':str(error)},500)







            return















        if path.startswith(('/widget-image/' , '/widget-video/', '/clip/', '/character/', '/avatar-preset/')):







            media = find_media(path, get_layout())







            if media is None:







                self.send_error(404, 'Migrated media not found')







            else:







                serve_media(self, media)







            return















        if path == '/editor':







            self.send_response(302)







            suffix = ('&' + parsed.query) if parsed.query else ''







            self.send_header('Location', '/index.html?tool=composer' + suffix)







            self.end_headers()







            return







        views = {'/': self.legacy_view, '/composer': 'composer', '/composer.html': 'composer',







                 '/overlay.html': self.legacy_view, '/chat-widget': 'chat',







                 '/giveaway': 'giveaway', '/giveaway_overlay.html': 'giveaway',







                 '/playroom-widget': 'playroom', '/playroom.html': 'playroom',







                 '/viewer_overlay.html': 'viewer'}







        if path in views:







            if views[path]=='viewer':







                self.serve_custom_file(os.path.join(DIST_DIR,'legacy_viewer.html'),'text/html; charset=utf-8');return







            self.serve_overlay(views[path])







            return







        if path in ('/dock', '/dock-offline.html'):







            self.serve_custom_file(os.path.join(DIST_DIR, 'dock.html'), 'text/html; charset=utf-8')







            return







        if path == '/dock-sw.js':







            body = b"self.addEventListener('install',()=>self.skipWaiting());self.addEventListener('activate',e=>e.waitUntil(self.registration.unregister()));"







            self.send_response(200)







            self.send_header('Content-Type', 'application/javascript')







            self.send_header('Content-Length', str(len(body)))







            self.send_header('Cache-Control', 'no-store')







            self.end_headers()







            self.wfile.write(body)







            return















        if path == '/api/overlay/events':







            qs = urllib.parse.parse_qs(parsed.query)







            try:







                after = int(qs['after'][0]) if 'after' in qs else None







                data = overlay_events.read(after, qs.get('epoch', [None])[0])







                self.send_json(data)







            except (ValueError, TypeError):







                self.send_json({'error': 'Invalid cursor'}, 400)







            return















        # 1. API: Composer Layout Sync for OBS







        if path == '/api/composer/layout':







            layout_data = get_layout()







            payload = json.dumps(layout_data, ensure_ascii=False).encode('utf-8')







            self.send_response(200)







            self.send_header('Content-Type', 'application/json; charset=utf-8')







            self.send_header('Content-Length', str(len(payload)))







            self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate')







            self.send_cors_headers()







            self.end_headers()







            self.wfile.write(payload)







            return















        # 2. API: Server status & OBS URLs







        if path == '/api/server_status':







            status_data = {







                'status': 'online',







                'port': PORT,







                'version': get_current_version(),







                'obs_composer_url': f"http://localhost:{PORT}/",







                'legacy_listeners': LEGACY_STATUS,







                'obs_overlay_url': f"http://127.0.0.1:{PORT}/overlay.html",







                'obs_dock_url': f"http://127.0.0.1:{PORT}/dock.html"







            }







            payload = json.dumps(status_data, ensure_ascii=False).encode('utf-8')







            self.send_response(200)







            self.send_header('Content-Type', 'application/json; charset=utf-8')







            self.send_header('Content-Length', str(len(payload)))







            self.send_cors_headers()







            self.end_headers()







            self.wfile.write(payload)







            return















        # 3. Other APIs







        if path.startswith('/api/'):







            self.handle_api(parsed)







            return















        # 4. Fallback File Routing (Overlay / Composer / Dock from dist or src)







        clean_path = path.lstrip('/')







        if clean_path in ['composer.html', 'overlay.html']:







            # Prefer dist/composer.html, fallback to src/composer.html







            target = os.path.join(DIST_DIR, 'composer.html')







            if not os.path.exists(target):







                target = os.path.join(SRC_DIR, 'composer.html')







            if os.path.exists(target):







                self.serve_custom_file(target, 'text/html; charset=utf-8')







                return















        if clean_path == 'dock.html':







            target = os.path.join(DIST_DIR, 'dock.html')







            if not os.path.exists(target):







                target = os.path.join(SRC_DIR, 'dock.html')







            if os.path.exists(target):







                self.serve_custom_file(target, 'text/html; charset=utf-8')







                return















        # Never reuse a cached application shell after a Dev restart.







        if clean_path in ('', 'index.html'):







            self.serve_custom_file(os.path.join(DIST_DIR, 'index.html'), 'text/html; charset=utf-8')







            return















        # If file is not in dist, check if it's in src







        dist_candidate = os.path.join(DIST_DIR, clean_path)







        if not os.path.exists(dist_candidate) and clean_path:







            src_candidate = os.path.join(SRC_DIR, clean_path)







            if os.path.exists(src_candidate) and os.path.isfile(src_candidate):







                mime = 'text/plain'







                if clean_path.endswith('.js'): mime = 'application/javascript; charset=utf-8'







                elif clean_path.endswith('.css'): mime = 'text/css; charset=utf-8'







                elif clean_path.endswith('.png'): mime = 'image/png'







                elif clean_path.endswith('.jpg') or clean_path.endswith('.jpeg'): mime = 'image/jpeg'







                elif clean_path.endswith('.svg'): mime = 'image/svg+xml'







                self.serve_custom_file(src_candidate, mime)







                return















        super().do_GET()















    def do_POST(self):







        parsed = urllib.parse.urlparse(self.path)







        path = parsed.path















        if path == '/api/avatars/clear-cache':
            import avatar_cache_service
            avatar_cache_service.clear_cache(DATA_ROOT)
            info = avatar_cache_service.get_cache_info(DATA_ROOT)
            self.send_json({'success': True, 'info': info})
            return

        if path == '/api/app/ready':
            global _app_frontend_ready
            _app_frontend_ready = True
            self.send_json({'ok': True, 'ready': True})
            return

        if path == '/api/platform/settings':
            try:
                size = int(self.headers.get('Content-Length', 0))
                data = json.loads(self.rfile.read(size).decode('utf-8'))
                _save_platform_settings(data)
                self.send_json({'success': True})
            except Exception as e:
                self.send_json({'success': False, 'error': str(e)})
            return

        if path == '/api/user-roster':
            try:
                size = int(self.headers.get('Content-Length', 0))
                payload = json.loads(self.rfile.read(size).decode('utf-8'))
                roster = payload.get('roster') if isinstance(payload, dict) and 'roster' in payload else payload
                if isinstance(roster, list):
                    _save_user_roster(roster)
                    self.send_json({'success': True, 'count': len(roster)})
                else:
                    self.send_json({'success': False, 'error': 'Invalid roster format'})
            except Exception as e:
                self.send_json({'success': False, 'error': str(e)})
            return

        if path == '/api/messages/inject':







            try:







                size = int(self.headers.get('Content-Length', 0))







                data = json.loads(self.rfile.read(size).decode('utf-8'))







                from chat_twitch import ChatMessage







                plat = data.get('platform', 'twitch').lower()







                extra = data.get('extra', {})







                if 'gift_name' in data: extra['gift_name'] = data['gift_name']







                if 'count' in data: extra['count'] = data['count']







                if 'months' in data: extra['months'] = data['months']







                if 'viewers' in data: extra['viewers'] = data['viewers']







                msg = ChatMessage(







                    platform=plat,







                    author=data.get('author') or data.get('username') or 'Viewer',







                    text=data.get('text', ''),







                    event=data.get('event', 'message'),







                    amount=data.get('amount'),







                    extra=extra







                )







                chat_bridge._on_message(plat, msg)







                self.send_json({'success': True, 'id': chat_bridge._msg_id_counter})







            except Exception as e:







                self.send_json({'success': False, 'error': str(e)}, 400)







            return















        if path == '/api/dictionary/import':







            try:







                size = int(self.headers.get('Content-Length', 0))







                raw_body = self.rfile.read(size).decode('utf-8')







                data = json.loads(raw_body)







                res = dict_manager.import_dict(data)







                self.send_json(res)







            except Exception as e:







                self.send_json({'success': False, 'error': str(e)}, 400)







            return























        if path in ('/api/clip-hotkey','/api/clip-markers'):







            self.send_json({'ok':False,'error':'พักการใช้งานมาร์กคลิปชั่วคราว'},410);return















        if path=='/api/game-chat-settings':







            try:







                origin=self.headers.get('Origin')







                if origin:







                    parsed_origin=urllib.parse.urlparse(origin)







                    if parsed_origin.scheme!='http' or parsed_origin.hostname not in ('localhost','127.0.0.1') or parsed_origin.port!=self.server.server_port:







                        self.send_json({'error':'Invalid origin'},403);return







                size=int(self.headers.get('Content-Length',0))







                if not 0<size<=32768:raise ValueError('Invalid request size')







                data=json.loads(self.rfile.read(size))







                from game_chat_settings import update, snapshot







                with GAME_CHAT_LOCK:







                    layout=get_layout(); old=dict(layout.get('legacyTools') or {})







                    for inherited_key,inherited_value in (layout.get('legacyChat') or {}).items():







                        if inherited_key.startswith(('game_overlay_','character_')) and inherited_key not in old:







                            old[inherited_key]=inherited_value







                    changed=update(old,data.get('mode'),data.get('key'),data.get('value'))







                    if data.get('key') in ('hotkey','hotkey_edit'):







                        desktop_overlays.rebind_game_hotkey('edit' if data['key']=='hotkey_edit' else 'toggle',data['value'],f'http://127.0.0.1:{self.server.server_port}')







                    layout['legacyTools']=changed;save_layout(layout)







                    merged={**(layout.get('legacyChat') or {}),**changed}







                    result=snapshot(merged)







                overlay_events.publish({'event':'DESKTOP_OVERLAY_STATE','payload':changed})







                self.send_json(result)







            except (ValueError,TypeError,OSError,AttributeError,RuntimeError) as error:self.send_json({'error':str(error)},400)







            return















        if path=='/api/viewer-overlay-settings':







            try:







                origin=self.headers.get('Origin')







                if origin:







                    parsed_origin=urllib.parse.urlparse(origin)







                    if parsed_origin.scheme!='http' or parsed_origin.hostname not in ('localhost','127.0.0.1') or parsed_origin.port!=self.server.server_port:







                        self.send_json({'error':'Invalid origin'},403);return







                size=int(self.headers.get('Content-Length',0))







                if not 0<size<=4096:raise ValueError('Invalid request size')







                values=json.loads(self.rfile.read(size))







                if not isinstance(values,dict):raise ValueError('Invalid viewer settings')







                from viewer_overlay_config import configure







                with GAME_CHAT_LOCK:







                    layout=get_layout();settings=layout.setdefault('legacyTools',{});configure(settings,values);save_layout(layout)







                overlay_events.publish({'event':'DESKTOP_OVERLAY_STATE','payload':settings})







                for item in desktop_overlays.instances.values():







                    if item['kind']=='viewer' and item['process'].poll() is None:







                        if 'alpha' in values:desktop_overlays.command(item,'set_alpha',alpha=settings.get('viewer_overlay_alpha',1))







                        if 'width' in values or 'height' in values:desktop_overlays.command(item,'set_size',width=settings.get('viewer_overlay_width',400),height=settings.get('viewer_overlay_height',80))







                self.send_json({'ok':True})







            except (ValueError,TypeError,OSError,AttributeError) as error:self.send_json({'error':str(error)},400)







            return















        if path in ('/api/dns/settings','/api/dns/test','/api/dns/clear'):







            try:







                origin=urllib.parse.urlparse(self.headers.get('Origin',''))







                if origin.scheme!='http' or origin.hostname not in ('localhost','127.0.0.1') or origin.port!=self.server.server_port:







                    self.send_json({'error':'Invalid origin'},403);return







                size=int(self.headers.get('Content-Length',0))







                if not 0<size<=4096:raise ValueError('invalid')







                data=json.loads(self.rfile.read(size))







                if path=='/api/dns/settings':self.send_json(dns_settings.save(data))







                elif path=='/api/dns/clear':







                    from network_dns import clear_dns_cache







                    clear_dns_cache();self.send_json({'ok':True})







                else:







                    from network_dns import test_dns_connection







                    config=dns_settings._validate(data)







                    ok,latency,ip,_=test_dns_connection(config['service'],config['custom'])







                    self.send_json({'ok':bool(ok),'latency_ms':round(latency),'message':'เชื่อมต่อบริการเสียงสำเร็จ' if ok else 'ทดสอบการเชื่อมต่อไม่สำเร็จ'})







            except (ValueError,TypeError,AttributeError):self.send_json({'error':'ข้อมูล DNS ไม่ถูกต้อง'},400)







            except Exception:self.send_json({'error':'ไม่สามารถทำรายการ DNS ได้'},500)







            return















        if path == '/api/logs/clear':







            log_capture.clear()







            self.send_json({'ok': True}); return















        if path == '/api/open-external':
            try:
                client_ip = self.client_address[0] if hasattr(self, 'client_address') and self.client_address else ''
                origin = urllib.parse.urlparse(self.headers.get('Origin', ''))
                is_local = client_ip in ('127.0.0.1', '::1', 'localhost') or origin.hostname in ('localhost', '127.0.0.1')
                if not is_local:
                    self.send_json({'error': 'Invalid origin'}, 403); return







                size = int(self.headers.get('Content-Length', 0))







                if not 0 < size <= 4096: raise ValueError('invalid size')







                data = json.loads(self.rfile.read(size))







                url = str(data.get('url', '')).strip()







                if not (url.startswith('http://') or url.startswith('https://')):







                    self.send_json({'error': 'Invalid URL scheme'}, 400); return







                import webbrowser







                webbrowser.open(url)







                self.send_json({'ok': True})







            except Exception as e:







                self.send_json({'error': str(e)}, 500)







            return















        if path in ['/api/apply-update', '/api/updater/apply']:

            try:

                res = restart_and_apply_update()

                self.send_json(res)

            except Exception as e:

                self.send_json({'success': False, 'message': str(e)}, 500)

            return

        if path in ['/api/updater/start-download']:

            try:

                up_info = check_for_update()

                if up_info.get('has_update'):

                    start_background_download(up_info)

                self.send_json({'success': True, 'update_info': up_info})

            except Exception as e:

                self.send_json({'success': False, 'message': str(e)}, 500)

            return



        if path == '/api/shutdown':

            self.send_json({'ok': True, 'message': 'โปรแกรมกำลังปิดตัวลง...'})

            def _delayed_exit():

                time.sleep(0.4)

                try:

                    app_presence.begin_shutdown()

                except Exception:

                    pass

                os._exit(0)

            threading.Thread(target=_delayed_exit, daemon=True).start()

            return















        if path == '/api/defender/apply':







            try:







                success = DefenderExclusionManager.apply_one_click_exclusion()







                self.send_json({'success': success, 'info': DefenderExclusionManager.get_status_info()})







            except Exception as e:







                self.send_json({'success': False, 'message': str(e)}, 500)







            return















        if path == '/api/chatbot/blocklist':







            try:







                origin=urllib.parse.urlparse(self.headers.get('Origin',''))







                if origin.scheme!='http' or origin.hostname not in ('localhost','127.0.0.1') or origin.port!=self.server.server_port:







                    self.send_json({'error':'Invalid origin'},403);return







                size=int(self.headers.get('Content-Length',0))







                if not 0<size<=65536:raise ValueError('invalid')







                data=json.loads(self.rfile.read(size));names=data.get('names');words=data.get('banned_words',[])







                if not isinstance(names,list) or len(names)>2000 or any(not isinstance(name,str) or len(name)>200 for name in names):raise ValueError('invalid')







                if not isinstance(words,list) or len(words)>2000 or any(not isinstance(word,str) or len(word)>200 for word in words):raise ValueError('invalid')







                chat_bridge.set_bot_blocklist(names,words);self.send_json({'ok':True})







            except (ValueError,TypeError,AttributeError):self.send_json({'error':'Invalid request'},400)







            return















        if path == '/api/clip-hotkey':







            try:







                origin=urllib.parse.urlparse(self.headers.get('Origin',''))







                if origin.scheme!='http' or origin.hostname not in ('localhost','127.0.0.1') or origin.port!=self.server.server_port:







                    self.send_json({'error':'Invalid origin'},403);return







                size=int(self.headers.get('Content-Length',0))







                if not 0<size<=1024:raise ValueError('ข้อมูลไม่ถูกต้อง')







                data=json.loads(self.rfile.read(size));self.send_json(clip_hotkey.set(data.get('shortcut','')))







            except (ValueError,TypeError,AttributeError) as error:self.send_json({'error':str(error) or 'ข้อมูลไม่ถูกต้อง'},400)







            except Exception:self.send_json({'error':'บันทึกปุ่มลัดไม่สำเร็จ'},500)







            return















        if path == '/api/obs/config':







            try:







                origin=urllib.parse.urlparse(self.headers.get('Origin',''))







                if origin.scheme!='http' or origin.hostname not in ('localhost','127.0.0.1') or origin.port!=self.server.server_port:







                    self.send_json({'error':'Invalid origin'},403);return







                size=int(self.headers.get('Content-Length',0))







                if not 0<size<=4096:raise ValueError('invalid')







                data=json.loads(self.rfile.read(size))







                self.send_json(obs_connection.save(data))







            except (ValueError,TypeError,AttributeError):self.send_json({'error':'ข้อมูล OBS ไม่ถูกต้อง'},400)







            except Exception:self.send_json({'error':'บันทึกการตั้งค่า OBS ไม่สำเร็จ'},500)







            return















        if path == '/api/obs/test':







            try:







                origin = urllib.parse.urlparse(self.headers.get('Origin', ''))







                if origin.scheme != 'http' or origin.hostname not in ('localhost', '127.0.0.1') or origin.port != self.server.server_port:







                    self.send_json({'ok': False, 'message': 'Invalid origin'}, 403); return







                size = int(self.headers.get('Content-Length', 0))







                if not 0 < size <= 4096: raise ValueError('Invalid request')







                data = json.loads(self.rfile.read(size))







                host = data.get('host', '').strip()







                port = int(data.get('port', 0))







                password = data.get('password', '')







                if not host or len(host) > 253 or any(c in host for c in '/\\@?#') or not 1 <= port <= 65535 or not isinstance(password, str): raise ValueError('Invalid request')







                if not password and not data.get('clear_password'): password = obs_connection.password_for(host, port)







                import obsws_python as obs







                client = None







                try:







                    client = obs.ReqClient(host=host, port=port, password=password, timeout=3)







                    version = client.get_version()







                    clip_markers.configure(host, port, password)







                    self.send_json({'ok': True, 'message': 'เชื่อมต่อ OBS สำเร็จ (OBS ' + str(getattr(version, 'obs_version', '')) + ')'})







                finally:







                    if client is not None:







                        try: client.base_client.ws.close()







                        except Exception: pass







            except (ValueError, TypeError, AttributeError, json.JSONDecodeError):







                self.send_json({'ok': False, 'message': 'ข้อมูลการเชื่อมต่อไม่ถูกต้อง'}, 400)







            except ImportError:







                self.send_json({'ok': False, 'message': 'ไม่พบส่วนเชื่อมต่อ OBS WebSocket ในโปรแกรม'}, 503)







            except Exception:







                self.send_json({'ok': False, 'message': 'เชื่อมต่อ OBS ไม่สำเร็จ ตรวจสอบ OBS, พอร์ต และรหัสผ่าน'}, 502)







            return















        if path == '/api/clip-markers':







            try:







                origin = urllib.parse.urlparse(self.headers.get('Origin', ''))







                if origin.scheme != 'http' or origin.hostname not in ('localhost', '127.0.0.1') or origin.port != self.server.server_port:







                    self.send_json({'ok': False, 'message': 'Invalid origin'}, 403); return







                size = int(self.headers.get('Content-Length', 0))







                if not 0 < size <= 1024: raise ValueError('Invalid request')







                data = json.loads(self.rfile.read(size))







                self.send_json(clip_markers.action(data.get('action')))







            except (ValueError, TypeError, AttributeError):







                self.send_json({'ok': False, 'message': 'คำสั่งไม่ถูกต้อง'}, 400)







            except OSError:







                self.send_json({'ok': False, 'message': 'เปิดหรือบันทึกไฟล์มาร์กคลิปไม่สำเร็จ'}, 500)







            return















        if path == '/api/supporters/action':







            try:







                origin=self.headers.get('Origin','');parsed_origin=urllib.parse.urlparse(origin)







                if parsed_origin.scheme!='http' or parsed_origin.hostname not in ('localhost','127.0.0.1') or parsed_origin.port!=self.server.server_port:







                    self.send_json({'ok':False,'error':'Invalid origin'},403);return







                size=int(self.headers.get('Content-Length',0))







                if not 0<size<=8*1024*1024:raise ValueError('Invalid request')







                data=json.loads(self.rfile.read(size))







                if not isinstance(data,dict):raise ValueError('Invalid request')







                from supporters_service import action







                self.send_json(action(data))







            except (ValueError,TypeError,AttributeError):self.send_json({'ok':False,'error':'ข้อมูลไม่ถูกต้อง'},400)







            return















        if path == '/api/window/popout':
            try:
                size = int(self.headers.get('Content-Length', 0))
                data = json.loads(self.rfile.read(size)) if size > 0 else {}
                query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                tool = data.get('tool') or query.get('tool', [''])[0]
                section = data.get('section') or query.get('section', [''])[0]
                main_url = f"http://127.0.0.1:{self.server.server_port}"
                res = handle_tool_popout(tool, main_url, section=section)
                self.send_json(res)
            except Exception as e:
                self.send_json({'error': str(e)}, 500)
            return

        if path == '/api/window/popout/close':
            try:
                size = int(self.headers.get('Content-Length', 0))
                data = json.loads(self.rfile.read(size)) if size > 0 else {}
                query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                tool = data.get('tool') or query.get('tool', [''])[0]
                tool = normalize_tool_name(tool)
                
                # Send JSON response immediately to prevent HTTP/COM deadlock with client fetch
                self.send_json({'ok': True, 'closing': tool})
                
                def _do_close():
                    tw = _tool_popout_windows.pop(tool, None)
                    if tw:
                        safe_destroy_window(tw)
                    try:
                        import webview
                        tool_no_hyphen = (tool or '').replace('-', ' ')
                        for w in list(getattr(webview, 'windows', [])):
                            w_title = (getattr(w, 'title', '') or '').lower()
                            w_url = (getattr(w, 'url', '') or '').lower()
                            # Never close main window
                            if 'broadcast playroom 3' in w_title and 'popout=' not in w_url:
                                continue
                            if tool and (tool in w_title or tool_no_hyphen in w_title or f"popout={tool}" in w_url):
                                safe_destroy_window(w)
                    except Exception:
                        pass
                threading.Thread(target=_do_close, daemon=True).start()
            except Exception as e:
                self.send_json({'error': str(e)}, 500)
            return

        if path == '/api/window/frame':







            origin=urllib.parse.urlparse(self.headers.get('Origin',''))







            if origin.scheme!='http' or origin.hostname not in ('localhost','127.0.0.1') or origin.port!=self.server.server_port:







                self.send_json({'ok':False},403);return







            try:







                size=int(self.headers.get('Content-Length',0))







                if not 0<size<512:raise ValueError('Invalid request')







                data=json.loads(self.rfile.read(size))







                from app_window_frame import action







                self.send_json(action(data.get('action'), data))







            except Exception:self.send_json({'ok':False},400)







            return















        if path == '/api/window/owner':







            try:







                origin=self.headers.get('Origin')







                if origin:







                    parsed_origin=urllib.parse.urlparse(origin)







                    if parsed_origin.scheme!='http' or parsed_origin.hostname not in ('localhost','127.0.0.1') or parsed_origin.port!=self.server.server_port:







                        self.send_json({'error':'Invalid origin'},403);return







                size=int(self.headers.get('Content-Length',0))







                if not 0<size<=1024:raise ValueError('Invalid request')







                data=json.loads(self.rfile.read(size))







                from app_window_ownership import set_tool_owner







                self.send_json(set_tool_owner(data.get('name','')))







            except (ValueError,TypeError,AttributeError):self.send_json({'error':'Invalid request'},400)







            return















        if path == '/api/chatbot/auth':







            try:







                origin = self.headers.get('Origin')







                if origin:







                    parsed_origin = urllib.parse.urlparse(origin)







                    if parsed_origin.scheme != 'http' or parsed_origin.hostname not in ('localhost', '127.0.0.1') or parsed_origin.port != self.server.server_port:







                        self.send_json({'error':'Invalid origin'},403); return







                size=int(self.headers.get('Content-Length',0))







                if not 0 < size <= 4096: raise ValueError('Invalid request')







                data=json.loads(self.rfile.read(size)); platform=data.get('platform');action=data.get('action')







                if platform not in ('twitch','kick') or action not in ('start','disconnect'):raise ValueError('Invalid request')







                if action == 'start':bot_accounts.start(platform)







                else:bot_accounts.disconnect(platform)







                self.send_json({'ok':True})







            except (ValueError, TypeError, AttributeError) as error:self.send_json({'error':str(error) or 'ไม่สามารถเริ่มเชื่อมต่อบัญชีได้'},400)







            return















        if path == '/api/chatbot/send':







            try:







                origin=self.headers.get('Origin')







                if origin:







                    parsed_origin=urllib.parse.urlparse(origin)







                    if parsed_origin.scheme!='http' or parsed_origin.hostname not in ('localhost','127.0.0.1') or parsed_origin.port!=self.server.server_port:







                        self.send_json({'error':'Invalid origin'},403);return







                size=int(self.headers.get('Content-Length',0))







                if not 0<size<=8192: raise ValueError('Invalid request')







                data=json.loads(self.rfile.read(size));message=data.get('message');targets=data.get('targets')







                if not isinstance(message,str) or not message.strip() or len(message)>480 or any(c in message for c in '\r\n') or not isinstance(targets,list) or not targets or len(set(targets))!=len(targets) or any(p not in ('twitch','kick') for p in targets): raise ValueError('ข้อความหรือแพลตฟอร์มไม่ถูกต้อง')







                results={}







                for platform in targets:







                    with chat_bridge._lock: client=chat_bridge._clients.get(platform)







                    if not client or not client.is_connected or not client.can_send:







                        results[platform]={'ok':False,'error':'บัญชีหรือแชทยังไม่พร้อม'};continue







                    try: results[platform]={'ok':bool(client.send_message(message.strip()))}







                    except Exception: results[platform]={'ok':False,'error':'ส่งข้อความไม่สำเร็จ'}







                self.send_json({'results':results})







            except (ValueError,TypeError,AttributeError): self.send_json({'error':'ข้อความหรือแพลตฟอร์มไม่ถูกต้อง'},400)







            return















        if path == '/api/translate/mode':







            try:







                size = int(self.headers.get('Content-Length', 0))







                data = json.loads(self.rfile.read(size)) if size else {}







                mode = data.get('mode', 'translate')







                chat_bridge.set_translate_mode(mode)
                if mode in ('translate', 'multilang'):
                    _save_platform_settings({'translate_mode': mode})







                self.send_json({'ok': True, 'mode': mode})







            except Exception as e:







                self.send_json({'error': str(e)}, 400)







            return















        if path == '/api/translate/provider':







            try:







                size = int(self.headers.get('Content-Length', 0))







                data = json.loads(self.rfile.read(size)) if size else {}







                provider = data.get('provider', 'google')







                if getattr(chat_bridge, 'translator', None):







                    chat_bridge.translator.provider = provider







                self.send_json({'ok': True, 'provider': provider})







            except Exception as e:







                self.send_json({'error': str(e)}, 400)







            return















        if path == '/api/test/chat':







            try:







                size = int(self.headers.get('Content-Length', 0))







                data = json.loads(self.rfile.read(size)) if size else {}







                plat = data.get('platform', 'Twitch')







                author = data.get('author', 'Viewer')







                text = data.get('text', '')







                from chat_bridge import ChatMessage







                chat_bridge._on_message(plat, ChatMessage(plat.lower(), author, text))







                self.send_json({'ok': True})







            except Exception as e:







                self.send_json({'error': str(e)}, 400)







            return















        if path == '/api/chatbot/config':







            try:







                origin = self.headers.get('Origin')







                if origin:







                    parsed_origin = urllib.parse.urlparse(origin)







                    if parsed_origin.scheme != 'http' or parsed_origin.hostname not in ('localhost', '127.0.0.1') or parsed_origin.port != self.server.server_port:







                        self.send_json({'error': 'Invalid origin'}, 403); return







                size = int(self.headers.get('Content-Length', 0))







                if not 0 < size <= 65536: raise ValueError('Invalid configuration')







                data = json.loads(self.rfile.read(size))







                if not isinstance(data, dict): raise ValueError('Invalid configuration')







                chat_bridge.bot.configure(data)







                self.send_json({'ok': True})







            except (ValueError, TypeError, AttributeError): self.send_json({'error': 'Invalid configuration'}, 400)







            return















        if path=='/api/app-instance/reopen':







            try:







                size=int(self.headers.get('Content-Length',0))







                if not 0<size<=4096:raise ValueError()







                data=json.loads(self.rfile.read(size))







                if data.get('project')!=APP_PROJECT_ID:raise ValueError()







                if not app_presence.reserve_launch():self.send_json({'error':'Instance is closing'},503);return







                try:
                    from app_window_frame import bring_main_window_to_front
                    bring_main_window_to_front()
                except Exception as e:
                    print(f"[REOPEN] Could not bring window to front: {e}", flush=True)
                self.send_json({'ok':True})







            except (ValueError,TypeError,AttributeError):self.send_json({'error':'Invalid instance'},400)







            return















        if path=='/api/app-presence/leave':







            try:







                size=int(self.headers.get('Content-Length',0))







                if not 0<size<=4096:raise ValueError()







                data=json.loads(self.rfile.read(size));client=data.get('client')







                if not isinstance(client,str) or len(client)>128:raise ValueError()







                app_presence.leave(client);self.send_json({'ok':True})







            except (ValueError,TypeError,AttributeError):self.send_json({'error':'Invalid client'},400)







            return















        if path=='/api/chat/delete':







            try:







                size=int(self.headers.get('Content-Length',0))







                if not 0<size<=4096:raise ValueError()







                data=json.loads(self.rfile.read(size));target=str(data['id'])







                with chat_bridge._lock:chat_bridge._messages=[msg for msg in chat_bridge._messages if str(msg['id'])!=target]







                overlay_events.publish({'event':'CHAT_DELETE','payload':{'id':target}})







                self.send_json({'ok':True})







            except (ValueError,TypeError,KeyError):self.send_json({'error':'Invalid message'},400)







            return















        if path in ('/api/dock/action','/api/dock/state'):







            try:







                size=int(self.headers.get('Content-Length',0))







                if not 0<size<=1048576:raise ValueError()







                data=json.loads(self.rfile.read(size))







                if not isinstance(data,dict):raise ValueError()







                if path.endswith('/state'):DOCK_STATE.clear();DOCK_STATE.update(data)







                else:overlay_events.publish({'event':'DOCK_CONTROL','payload':data})







                self.send_json({'ok':True})







            except (ValueError,TypeError):self.send_json({'error':'Invalid Dock data'},400)







            return















        if path=='/api/chat-config/preview':







            try:







                size=int(self.headers.get('Content-Length',0))







                if not 0<size<=1048576:raise ValueError()







                widget=json.loads(self.rfile.read(size))







                if not isinstance(widget,dict):raise ValueError()







                self.send_json(build_chat_config(widget,(get_layout() or {}).get('legacyChat') or {}))







            except (ValueError,TypeError):self.send_json({'error':'Invalid chat settings'},400)







            return















        if path=='/api/giveaway-settings':







            try:







                size=int(self.headers.get('Content-Length',0))







                if not 0<size<=5*1024*1024:raise ValueError('Invalid settings size')







                data=json.loads(self.rfile.read(size))







                if not isinstance(data,dict) or not isinstance(data.get('code'),str) or len(data.get('code',''))>100:raise ValueError('Invalid settings')







                data={key:data[key] for key in ('code','duration','display','imageUrl') if key in data};layout=get_layout();layout.setdefault('legacyTools',{})['giveaway']=data;save_layout(layout);self.send_json({'saved':True})







            except (ValueError,OSError) as error:self.send_json({'error':str(error)},400)







            return







        if path=='/api/desktop-overlays':







            try:







                size=int(self.headers.get('Content-Length',0))







                if not 0<size<=65536:raise ValueError('Invalid request')







                data=json.loads(self.rfile.read(size))







                if data.get('action')=='configure':







                    layout=get_layout();settings=layout.setdefault('legacyTools',{})
                    entries=data.get('overlays')
                    if entries is not None:
                        if not isinstance(entries,list) or len(entries)>3:raise ValueError('Overlay+ รองรับสูงสุด 3 หน้าต่าง')
                        for entry in entries:
                            if not isinstance(entry,dict) or (entry.get('url') and urllib.parse.urlparse(entry['url']).scheme not in ('http','https')):raise ValueError('URL ไม่ถูกต้อง')
                        settings['more_overlays']=entries







                    game=data.get('game') or {}







                    for key,low,high in [('game_overlay_width',120,3840),('game_overlay_height',80,2160),('game_overlay_font_size',8,120),('game_overlay_alpha',0,1)]:







                        if key in game:settings[key]=max(low,min(high,float(game[key]))) if key.endswith('alpha') else int(max(low,min(high,float(game[key]))))







                    if 'game_overlay_text_color' in game:







                        import re







                        if not re.fullmatch(r'#[0-9a-fA-F]{6}',str(game['game_overlay_text_color'])):raise ValueError('สีไม่ถูกต้อง')







                        settings['game_overlay_text_color']=game['game_overlay_text_color']







                    from viewer_overlay_config import configure







                    viewer=data.get('viewer') or {}







                    configure(settings,viewer)







                    save_layout(layout);overlay_events.publish({'event':'DESKTOP_OVERLAY_STATE','payload':settings})







                    for item in desktop_overlays.instances.values():







                        if game and item['kind']=='game' and item['process'].poll() is None:







                            desktop_overlays.command(item,'set_alpha',alpha=settings.get('game_overlay_alpha',.85))







                            desktop_overlays.command(item,'set_size',width=settings.get('game_overlay_width',360),height=settings.get('game_overlay_height',500))







                        elif viewer and item['kind']=='viewer' and item['process'].poll() is None:







                            desktop_overlays.command(item,'set_alpha',alpha=settings.get('viewer_overlay_alpha',1))







                            desktop_overlays.command(item,'set_size',width=settings.get('viewer_overlay_width',400),height=settings.get('viewer_overlay_height',80))







                    self.send_json({'saved':True})







                else:self.send_json(desktop_overlays.act(data.get('action'),data.get('kind'),f'http://127.0.0.1:{self.server.server_port}'))







            except (ValueError,OSError) as error:self.send_json({'error':str(error)},400)







            return







        if path == '/api/playroom/import':







            try:







                origin=self.headers.get('Origin')







                if origin:







                    parsed_origin=urllib.parse.urlparse(origin)







                    if parsed_origin.scheme!='http' or parsed_origin.hostname not in ('localhost','127.0.0.1') or parsed_origin.port!=self.server.server_port:







                        self.send_json({'error':'Invalid origin'},403);return







                size=int(self.headers.get('Content-Length',0))







                result=playroom_media.import_file(self.rfile,size,self.headers.get('X-Filename',''))







                self.send_json(result)







            except (ValueError,OSError) as error:self.send_json({'error':str(error)},400)







            return







        if path.startswith('/api/rvc/'):







            try:







                rvc_service.require_full()







                origin = self.headers.get('Origin')







                if origin and origin != 'null' and urllib.parse.urlparse(origin).hostname not in ('localhost','127.0.0.1','tauri.localhost'):







                    self.send_json({'error':'Forbidden origin'},403)







                    return







                if path == '/api/rvc/import':







                    original_name = urllib.parse.unquote(self.headers.get('X-Filename',''))







                    name = os.path.basename(original_name)







                    if name != original_name or not name.lower().endswith(('.pth','.index')):







                        raise ValueError('Choose a .pth or .index model file')







                    size = int(self.headers.get('Content-Length',0))







                    if not 0 < size <= 2147483648:raise ValueError('Invalid model size')







                    rvc_service.model_dir.mkdir(parents=True,exist_ok=True)







                    target=rvc_service.model_dir/name







                    if target.exists():raise ValueError('A file with this name already exists')







                    temporary=None







                    try:







                        with tempfile.NamedTemporaryFile(dir=rvc_service.model_dir,suffix='.partial',delete=False) as stream:







                            temporary=stream.name







                            remaining=size







                            while remaining:







                                chunk=self.rfile.read(min(1048576,remaining))







                                if not chunk:raise ValueError('Upload incomplete')







                                stream.write(chunk);remaining-=len(chunk)







                        os.replace(temporary,target)







                    finally:







                        if temporary and os.path.isfile(temporary):os.remove(temporary)







                    self.send_json({'ok':True,'models':rvc_service.public_models()})







                    return







                length=int(self.headers.get('Content-Length',0))







                if length>1048576:raise ValueError('Invalid request size')







                body=json.loads(self.rfile.read(length)) if length else {}







                if path == '/api/rvc/select':result=rvc_service.select(body.get('id'),body.get('enabled',True))







                elif path == '/api/rvc/download':result=rvc_service.download(body.get('id'))







                elif path == '/api/rvc/cancel':result=rvc_service.cancel()







                elif path == '/api/rvc/open-folder':







                    rvc_service.model_dir.mkdir(parents=True,exist_ok=True)







                    os.startfile(str(rvc_service.model_dir))







                    result={'ok':True}







                else:







                    self.send_json({'error':'Unknown RVC endpoint'},404)







                    return







                self.send_json(result)







            except PermissionError as error:self.send_json({'error':str(error)},403)







            except (ValueError,TypeError,OSError) as error:self.send_json({'error':str(error)},400)







            except Exception as error:self.send_json({'error':str(error)},500)







            return















        if path == '/api/composer/normalize':







            try:







                size = int(self.headers.get('Content-Length', 0))







                if not 0 < size <= 8388608:







                    raise ValueError('Invalid layout size')







                self.send_json(normalize_layout(json.loads(self.rfile.read(size))))







            except (ValueError, TypeError, KeyError):







                self.send_json({'error': 'Invalid Composer profile'}, 400)







            return















        if path == '/api/overlay/events':







            try:







                size = int(self.headers.get('Content-Length', 0))







                if not 0 < size <= 1048576:







                    self.send_json({'error': 'Invalid event size'}, 400)







                    return







                item = json.loads(self.rfile.read(size))







                sequence = overlay_events.publish(item)







                if item.get('event') == 'CHAT_CLEAR':







                    chat_bridge.clear_messages()







                self.send_json({'ok': True, 'cursor': sequence})







            except (ValueError, TypeError, AttributeError):







                self.send_json({'error': 'Invalid event'}, 400)







            return















        if path == '/api/composer/layout':







            content_length = int(self.headers.get('Content-Length', 0))







            body = self.rfile.read(content_length).decode('utf-8')







            try:







                data = json.loads(body)







                save_layout(data)







                resp = {'status': 'ok', 'saved': True, 'timestamp': time.time()}







            except Exception as e:







                resp = {'status': 'error', 'message': str(e)}















            payload = json.dumps(resp, ensure_ascii=False).encode('utf-8')







            self.send_response(200)







            self.send_header('Content-Type', 'application/json; charset=utf-8')







            self.send_header('Content-Length', str(len(payload)))







            self.send_cors_headers()







            self.end_headers()







            self.wfile.write(payload)







            return















        self.send_response(404)







        self.send_cors_headers()







        self.end_headers()















    def serve_overlay(self, view='composer'):







        if view=='chat' and (get_layout() or {}).get('legacyChat'):







            self.serve_custom_file(os.path.join(DIST_DIR,'legacy_chat.html'),'text/html; charset=utf-8')







            return







        target = os.path.join(DIST_DIR, 'composer.html')







        if not os.path.isfile(target):







            target = os.path.join(SRC_DIR, 'composer.html')







        with open(target, 'r', encoding='utf-8') as stream:







            html = stream.read()







        html = html.replace('<head>', '<head><script>window.BP3LegacyView=' + json.dumps(view) + ';</script>', 1)







        body = html.encode('utf-8')







        self.send_response(200)







        self.send_header('Content-Type', 'text/html; charset=utf-8')







        self.send_header('Content-Length', str(len(body)))







        self.send_header('Cache-Control', 'no-store')







        self.send_cors_headers()







        self.end_headers()







        self.wfile.write(body)















    def send_json(self, data, status=200):







        body = json.dumps(data, ensure_ascii=False).encode('utf-8')







        self.send_response(status)







        self.send_header('Content-Type', 'application/json; charset=utf-8')







        self.send_header('Content-Length', str(len(body)))







        self.send_header('Cache-Control', 'no-store')







        self.send_cors_headers()







        self.end_headers()







        self.wfile.write(body)















    def serve_custom_file(self, filepath, mime_type):







        try:







            with open(filepath, 'rb') as f:







                content = f.read()







            self.send_response(200)







            self.send_header('Content-Type', mime_type)







            self.send_header('Content-Length', str(len(content)))







            self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate')







            self.send_cors_headers()







            self.end_headers()







            self.wfile.write(content)







        except Exception as e:







            self.send_response(500)







            self.end_headers()















    def handle_api(self, parsed):







        qs = urllib.parse.parse_qs(parsed.query)







        path = parsed.path







        







        # 1. Handle TTS Audio streaming (with high-speed LRU memory cache)







        if path == '/api/tts':







            text = qs.get('text', [''])[0]







            gender = qs.get('gender', ['female'])[0]







            rate = qs.get('rate', ['+0%'])[0]







            pitch = qs.get('pitch', ['+0Hz'])[0]







            volume = qs.get('volume', ['+0%'])[0]







            







            try:







                preview = qs.get('preview', ['0'])[0] == '1'







                processed_text = text if preview else dict_manager.apply_replace(text)







                







                # Check RVC state for accurate caching







                rvc_enabled = bool(rvc_service and getattr(rvc_service, 'data', {}).get('enabled') and getattr(rvc_service, 'data', {}).get('loaded'))







                rvc_model = getattr(rvc_service, 'data', {}).get('selected') if rvc_enabled else None







                cache_key = (processed_text, gender, rate, pitch, volume, preview, rvc_enabled, rvc_model)















                cached_hit = None







                with _TTS_CACHE_LOCK:







                    if cache_key in _TTS_AUDIO_CACHE:







                        cached_hit = _TTS_AUDIO_CACHE[cache_key]







                        _TTS_AUDIO_CACHE.move_to_end(cache_key)















                if cached_hit:







                    audio_bytes, audio_mime = cached_hit







                else:







                    audio_bytes = tts_service.generate_audio_bytes(processed_text, gender, rate, pitch, volume)







                    if audio_bytes:







                        if preview:







                            audio_mime = 'audio/mpeg'







                        else:







                            try:







                                audio_bytes, audio_mime = rvc_service.convert(audio_bytes)







                            except Exception:







                                import logging







                                logging.getLogger('tts_service').exception('RVC conversion failed; returning original Edge-TTS audio')







                                audio_mime = 'audio/mpeg'







                        with _TTS_CACHE_LOCK:







                            _TTS_AUDIO_CACHE[cache_key] = (audio_bytes, audio_mime)







                            if len(_TTS_AUDIO_CACHE) > _TTS_CACHE_MAX:







                                _TTS_AUDIO_CACHE.popitem(last=False)















                if audio_bytes:







                    self.send_response(200)







                    self.send_header('Content-Type', audio_mime)







                    self.send_header('Content-Length', str(len(audio_bytes)))







                    self.send_cors_headers()







                    self.end_headers()







                    try:self.wfile.write(audio_bytes)







                    except (BrokenPipeError,ConnectionResetError,ConnectionAbortedError):pass







                    return







                else:







                    import logging







                    logging.getLogger('tts_service').warning('TTS synthesis returned no audio')







                    self.send_response(500)







                    self.send_cors_headers()







                    self.end_headers()







                    return







            except Exception:







                import logging







                logging.getLogger('tts_service').exception('TTS request failed')







                self.send_response(500)







                self.send_cors_headers()







                self.end_headers()







                return















        response_data = {}







        if path == '/api/connect':







            platform = qs.get('platform', [''])[0]







            target = qs.get('target', [''])[0]







            response_data = chat_bridge.connect(platform, target)







        elif path == '/api/disconnect':







            platform = qs.get('platform', [''])[0]







            response_data = chat_bridge.disconnect(platform)







        elif path == '/api/status':







            response_data = chat_bridge.get_status()







        elif path == '/api/messages':







            last_id = int(qs.get('last_id', [0])[0])







            response_data = {'messages': chat_bridge.get_messages(last_id)}







        elif path == '/api/dictionary':







            response_data = dict_manager.get_all()







        elif path == '/api/dictionary/sync':







            response_data = dict_manager.sync_remote()







        elif path == '/api/dictionary/add':







            find_w = qs.get('find', [''])[0]







            rep_w = qs.get('replace', [''])[0]







            response_data = dict_manager.add_word(find_w, rep_w)







        elif path == '/api/dictionary/delete':







            word = qs.get('word', [''])[0]







            response_data = dict_manager.delete_word(word)







        elif path == '/api/platform/settings':
            response_data = _load_platform_settings()
        elif path == '/api/user-roster':
            response_data = {'success': True, 'roster': _load_user_roster()}

        elif path == '/api/plugins':
            try:
                from plugin_manager import plugin_manager
                response_data = {'plugins': plugin_manager.get_plugin_list()}
            except Exception:
                response_data = {'plugins': []}

        elif path == '/api/version':







            response_data = {'version': get_current_version(), 'product': 'broadcast-playroom-3', 'build_type': get_build_type()}







        elif path == '/api/check-update':

            up_info = check_for_update()

            if up_info.get('has_update'):

                try:

                    start_background_download(up_info)

                except Exception as exc:

                    pass

            up_info['download_status'] = get_update_runtime_status()

            response_data = up_info



        elif path in ['/api/update-status', '/api/updater/status']:

            response_data = get_update_runtime_status()



        elif path == '/api/apply-update':

            response_data = restart_and_apply_update()







        elif path == '/api/defender/status':







            response_data = DefenderExclusionManager.get_status_info()







        elif path == '/api/logs':







            query = urllib.parse.parse_qs(parsed.query)







            try:







                since = float(query.get('since', ['0'])[0])







            except (ValueError, TypeError):







                since = 0.0







            logs = log_capture.get_logs(since=since)







            latest_time = logs[-1]['time'] if logs else since







            response_data = {'logs': logs, 'latest_time': latest_time}







        elif path == '/api/open-external':







            query = urllib.parse.parse_qs(parsed.query)







            url = query.get('url', [''])[0].strip()







            if url.startswith('http://') or url.startswith('https://'):







                import webbrowser







                webbrowser.open(url)







                response_data = {'ok': True}







            else:







                response_data = {'error': 'Invalid URL scheme'}







        else:







            response_data = {'error': 'Unknown endpoint'}















        payload = json.dumps(response_data, ensure_ascii=False).encode('utf-8')







        self.send_response(200)







        self.send_header('Content-Type', 'application/json; charset=utf-8')







        self.send_header('Content-Length', str(len(payload)))







        self.send_cors_headers()







        self.end_headers()







        self.wfile.write(payload)















def is_port_in_use(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(('127.0.0.1', int(port)))
            return False
        except OSError:
            return True















def start_server():







    global PORT







    config_file = os.path.join(os.path.dirname(__file__), 'legacy_compat.json')







    if os.path.isfile(config_file):







        with open(config_file, 'r', encoding='utf-8') as stream:







            configured = json.load(stream)







        if 'composer' in configured:







            candidate = int(configured['composer'])







            if not 1 <= candidate <= 65535:







                raise ValueError('Invalid Composer port')







            PORT = candidate







    HTTPServer.allow_reuse_address = True







    if is_port_in_use(PORT):







        raise OSError(f'Composer port {PORT} is busy. Close the previous Broadcast Playroom instance; the OBS URL will not be silently changed.')







    







    from loopback_server import LoopbackServer







    server = LoopbackServer(('127.0.0.1', PORT), QuietHandler)







    return server















def find_browser():
    candidates = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"),
    ]
    for c in candidates:
        if os.path.isfile(c):
            return c
    return None















def open_app_window(main_url):
    curr_ver = get_current_version()
    browser_bin = find_browser()
    launched = False

    app_profile_dir = os.path.join(str(DATA_ROOT), 'browser_profile')
    os.makedirs(app_profile_dir, exist_ok=True)
    # Purge stale browser cache to guarantee immediate UI update without requiring Ctrl+Shift+R
    for cache_sub in ['Default/Cache', 'Default/Code Cache', 'Default/GPUCache', 'ShaderCache', 'GrShaderCache']:
        cp = os.path.join(app_profile_dir, *cache_sub.split('/'))
        if os.path.isdir(cp):
            try:
                import shutil
                shutil.rmtree(cp, ignore_errors=True)
            except Exception:
                pass

    cache_delim = '&' if '?' in main_url else '?'
    main_url_busted = f"{main_url}{cache_delim}_v={curr_ver}_{int(time.time())}"

    if browser_bin:
        cmd = [
            browser_bin,
            f"--app={main_url_busted}",
            f"--user-data-dir={app_profile_dir}",
            "--disable-popup-blocking",
            "--new-window",
            "--disable-background-timer-throttling",
            "--disable-backgrounding-occluded-windows",
            "--disable-renderer-backgrounding",
            "--disable-features=CalculateNativeWinOcclusion,IntensiveWakeUpThrottling,QuickIntensiveWakeUpThrottlingAfterLoading,WebAppWindowControlsOverlay",
            "--disable-http-cache",
            "--disable-application-cache",
            "--disk-cache-size=1",
            "--media-cache-size=1",
            "--autoplay-policy=no-user-gesture-required",
            "--disable-extensions",
            "--disable-plugins",
            "--disable-component-extensions-with-background-pages",
            "--disable-default-apps",
            "--disable-features=Translate,AutofillServerCommunication,AutofillEnableAccountWalletStorage,PasswordGeneration",
            "--disable-save-password-bubble",
            "--disable-single-click-autofill",
            "--disable-autofill-keyboard-accessory-view",
            "--password-store=basic",
            "--no-default-browser-check",
            "--no-first-run",
            "--window-size=1600,950",
            "--window-position=100,50"
        ]
        print(f"[LAUNCH] Opening Desktop App window via {os.path.basename(browser_bin)} (Popouts & Title Bar Native)...", flush=True)
        try:
            proc = subprocess.Popen(cmd)
            launched = True
            def _watch_app_window_icon():
                start_t = time.time()
                while time.time() - start_t < 35:
                    try:
                        from app_window_frame import apply_icon_to_app_windows
                        if apply_icon_to_app_windows():
                            time.sleep(1.0)
                        else:
                            time.sleep(0.3)
                    except Exception:
                        time.sleep(0.5)
            threading.Thread(target=_watch_app_window_icon, daemon=True).start()
            time.sleep(1.0)
            if proc.poll() is not None and proc.returncode != 0:
                print(f"[WARN] App mode exited unexpectedly (code {proc.returncode}), opening browser...", flush=True)
                webbrowser.open(main_url)
        except Exception as e:
            print(f"[WARN] Failed to open app mode ({e}), falling back to default browser...", flush=True)
            webbrowser.open(main_url)
            launched = True

    if not launched:
        print("[LAUNCH] Opening in default web browser...", flush=True)
        webbrowser.open(main_url)























class ExistingInstanceClosing(Exception):







    pass























def reuse_existing_server():







    base=f'http://127.0.0.1:{PORT}';verified=False







    try:







        with urllib.request.urlopen(base+'/api/app-instance',timeout=2) as response:







            data=json.load(response)







        if data.get('application')!='BroadcastPlayroom3' or data.get('project')!=APP_PROJECT_ID or data.get('edition')!=rvc_service.edition:return False







        verified=True







        if data.get('closing'):raise ExistingInstanceClosing()







        request=urllib.request.Request(base+'/api/app-instance/reopen',data=json.dumps({'project':APP_PROJECT_ID}).encode(),headers={'Content-Type':'application/json'},method='POST')







        with urllib.request.urlopen(request,timeout=2) as response:







            return json.load(response).get('ok') is True







    except OSError:







        if verified:raise ExistingInstanceClosing()







        return False







    except (ValueError,AttributeError):return False























def main():







    global LEGACY_STATUS, LEGACY_FILTER_IMPORT_ENABLED







    is_headless = '--headless' in sys.argv

    _single_instance_mutex = None
    if not is_headless and os.name == 'nt':
        import ctypes
        from ctypes import wintypes
        kernel32 = ctypes.windll.kernel32
        kernel32.CreateMutexW.argtypes = [wintypes.LPCVOID, wintypes.BOOL, wintypes.LPCWSTR]
        kernel32.CreateMutexW.restype = wintypes.HANDLE
        mutex_name = f"Local\\BroadcastPlayroom3_App_Mutex_{APP_PROJECT_ID}"
        _single_instance_mutex = kernel32.CreateMutexW(None, True, mutex_name)
        if kernel32.GetLastError() == 183:  # ERROR_ALREADY_EXISTS
            print('[INFO] Another instance of Broadcast Playroom is already running. Focusing existing window and exiting cleanly...', flush=True)
            deadline = time.monotonic() + 3.0
            while time.monotonic() < deadline:
                try:
                    if reuse_existing_server():
                        break
                except Exception:
                    pass
                time.sleep(0.2)
            try:
                from app_window_frame import bring_main_window_to_front
                bring_main_window_to_front()
            except Exception:
                pass
            return 0







    no_splash = True  # Splash completely disabled as requested for instant startup







    splash_ctrl = None







    if not no_splash:







        try:







            from splash import create_splash







            splash_ctrl = create_splash()







            global _GLOBAL_SPLASH_CTRL







            _GLOBAL_SPLASH_CTRL = splash_ctrl







            splash_ctrl.set_progress(15, "กำลังตรวจสอบพอร์ตและเริ่มต้นระบบ...")



        except Exception:



            splash_ctrl = None



    try:

        if apply_pending_update_on_startup(splash_ctrl):

            print("[UPDATER] Successfully applied pending update on startup!", flush=True)

    except Exception as exc:

        print(f"[UPDATER] Startup update check failed: {exc}", flush=True)







    deadline=time.monotonic()+12







    while True:







        try:







            server = start_server()







            break







        except OSError as error:







            try:







                if reuse_existing_server():







                    print('[INFO] Broadcast Playroom is already running on port 8801. Re-opening app window...', flush=True)







                    print('[INFO] ตรวจพบว่าเซิร์ฟเวอร์ Broadcast Playroom 3 กำลังทำงานอยู่แล้วที่พอร์ต 8801 กำลังเปิดหน้าต่างโปรแกรมขึ้นมาให้ครับ', flush=True)







                    close_splash()







                    try:
                        from app_window_frame import bring_main_window_to_front
                        bring_main_window_to_front()
                    except Exception:
                        pass







                    return 0







            except ExistingInstanceClosing:







                if time.monotonic()<deadline:







                    time.sleep(.2)







                    continue







            print(f'[ERROR] {error}',flush=True)







            return 1







    donation_goal_service.sync(get_layout())







    avatar_mic_service.sync(get_layout())







    server_thread = threading.Thread(target=server.serve_forever, daemon=True)







    server_thread.start()







    legacy_servers, LEGACY_STATUS = start_legacy_servers(QuietHandler, PORT, os.path.join(os.path.dirname(__file__), 'legacy_compat.json'))







    LEGACY_FILTER_IMPORT_ENABLED = True







    try:







        from legacy_obs_settings import migrate as migrate_legacy_obs







        migrate_legacy_obs(obs_connection)







    except Exception:







        import logging







        logging.getLogger('obs_connection').warning('Could not import legacy OBS settings')







    obs_connection.start()







    # Clip Marker is temporarily suspended; do not register a global hotkey.















    desktop_overlays._ensure_hotkeys('game',f'http://127.0.0.1:{PORT}')







    desktop_overlays._ensure_hotkeys('overlay+',f'http://127.0.0.1:{PORT}')







    main_url = f"http://127.0.0.1:{PORT}/index.html?v={get_current_version()}"







    dock_url = f"http://127.0.0.1:{PORT}/dock.html"







    comp_url = f"http://127.0.0.1:{PORT}/composer.html"







    over_url = f"http://127.0.0.1:{PORT}/overlay.html"















    print("============================================================", flush=True)







    print("   Broadcast Playroom 3 (Live Dev & OBS Server)", flush=True)







    print("============================================================", flush=True)







    print(f"   [1] หน้าต่างหลักโปรแกรม:      {main_url}", flush=True)







    print(f"   [2] OBS Custom Dock:         {dock_url}", flush=True)







    print(f"   [3] OBS Live Overlay:        {comp_url}", flush=True)







    print(f"   [4] OBS Overlay (Alias):     {over_url}", flush=True)







    print("============================================================", flush=True)







    print("   * Close the last main app window or press Ctrl+C here to stop.", flush=True)







    print("============================================================\n", flush=True)















    try: overlay_events.prune_chat_log()







    except (OSError, UnicodeError): logging.getLogger(__name__).exception('Unable to prune chat log')















    if splash_ctrl:







        splash_ctrl.set_progress(90, "กำลังเปิดหน้าต่างหลัก...")







    if not is_headless:







        open_app_window(main_url)







    def _close_splash_delayed():







        time.sleep(0.5)







        close_splash()







    threading.Thread(target=_close_splash_delayed, daemon=True).start()















    # Closing the last main window releases owned servers after a short reopen grace.







    try:







        while True:







            if app_presence.should_exit():







                print('[INFO] Main app closed; stopping owned services and releasing ports.',flush=True)







                break







            if time.time() - overlay_events._last_log_cleanup >= 3600:







                try: overlay_events.prune_chat_log()







                except (OSError, UnicodeError): logging.getLogger(__name__).exception('Unable to prune chat log')







            time.sleep(.5)







    except KeyboardInterrupt:







        print("\n[INFO] Stopping Dev Server...")







    finally:







        clip_hotkey.stop()







        obs_connection.stop()







        app_presence.begin_shutdown()







        chat_bridge.bot.stop()







        desktop_overlays.stop()







        now_playing_service.stop()







        donation_goal_service.stop()







        avatar_mic_service.stop()







        for legacy_server in legacy_servers:







            legacy_server.shutdown()







            legacy_server.server_close()







        server.shutdown()







        server.server_close()







        sys.exit(0)















# Keep chat history beside the active profile, including isolated test profiles.







overlay_events.chat_log_path=lambda: Path(LAYOUT_FILE).resolve().parent / "log.txt"















if __name__ == '__main__':







    sys.exit(main() or 0)







