"""chat_kick.py — KICK (kick.com) live chat client

เชื่อมต่อ KICK chat ผ่าน Pusher WebSocket (anonymous/read-only — ไม่ต้อง OAuth)

วิธีเชื่อม:
  1. HTTP resolve: GET kick.com/api/v2/channels/{slug}
     (header Accept-Language: en-US สำคัญ กัน Cloudflare 403)
     → ได้ chatroom.id
  2. Pusher WebSocket: wss://ws-us2.pusher.com/app/{APP_KEY}?protocol=7
     → subscribe "chatrooms.{id}.v2" (auth="" = anonymous)
  3. รับ events:
     - AppMessageEvent            → chat ปกติ (event="message")
     - GiftedSubscriptionsEvent   → มอบ sub (event="subgift")
     - LuckyUsersWhoGotGiftSubscriptionsEvent → ผู้รับ sub (event="subgift")
     - pusher:ping                → ตอบ pusher:pong (keepalive)

ข้อจำกัด (anonymous channel):
  - ไม่มี bits/donations (KICK ส่งผ่าน Streamlabs/StreamElements แยก)
  - ไม่มี raids/follows (ต้อง OAuth EventSub)
  - ได้แค่ chat + gifted subscriptions

การใช้งาน:
    client = KickChat(on_message=callback)
    client.connect("trainwreckstv")  # slug (username)
    ...
    client.disconnect()
"""
from __future__ import annotations

import json
import re
import threading
import time
import uuid
from typing import Callable, Optional

from chat_twitch import ChatMessage  # reuse shared dataclass

# websocket-client (sync) — daemon thread เหมือน Twitch IRC
try:
    import websocket
    _WS_AVAILABLE = True
    _WS_IMPORT_ERROR: Optional[str] = None
except Exception as exc:  # noqa: BLE001
    _WS_AVAILABLE = False
    _WS_IMPORT_ERROR = str(exc)
    websocket = None  # type: ignore[assignment]

# ---------------------------------------------------------------------- #
# KICK API constants
# ---------------------------------------------------------------------- #
KICK_API_BASE = "https://kick.com/api/v2/channels"
# KICK ใช้ Pusher cluster ws-us2 + public app key (ค่า default ของหน้าเว็บ)
KICK_PUSHER_CLUSTER = "ws-us2"
KICK_PUSHER_APP_KEY = "32cbd69e4b950bf97679"
KICK_PUSHER_URL = (
    f"wss://{KICK_PUSHER_CLUSTER}.pusher.com/app/{KICK_PUSHER_APP_KEY}"
    "?protocol=7&client=js&version=8.4.0"
)
# header สำคัญ — Accept-Language: en-US กัน Cloudflare 403
KICK_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept": "application/json",
    "Accept-Language": "en-US,en;q=0.9",
}

# regex strip [emote:id:name] tokens ออกจากข้อความ
_EMOTE_TOKEN_RE = re.compile(r"\[(?:emote|\d+):\d+:[^\]]+\]", re.IGNORECASE)
# กระชับ space หลายช่อง
_MULTI_SPACE_RE = re.compile(r" {2,}")


def _realtime_pusher_url(timeout: float = 10.0) -> str:
    """Discover the public realtime provider instead of relying on an expired key."""
    import requests
    body = {'client': {'id': str(uuid.uuid4()), 'type': 'web'},
            'capabilities': {'accepted_providers': [{'provider': 'pusher'}]}}
    headers = dict(KICK_HEADERS, Origin='https://kick.com')
    try:
        response = requests.post('https://web.kick.com/api/v1/realtime/connection', json=body, headers=headers, timeout=timeout)
        response.raise_for_status()
        data = response.json().get('data', {})
        for entry in data.get('connections', []):
            credentials = entry.get('credentials') or {}
            key, cluster = credentials.get('app_key', ''), credentials.get('cluster', '')
            if entry.get('provider') == 'pusher' and re.fullmatch(r'[A-Za-z0-9]+', key) and re.fullmatch(r'[a-z0-9-]+', cluster):
                return f'wss://ws-{cluster}.pusher.com/app/{key}?protocol=7&client=js&version=8.4.0'
        raise ValueError('ไม่พบข้อมูล Pusher')
    except Exception as exc:
        raise RuntimeError(f'KICK: ไม่สามารถค้นหาข้อมูลเชื่อมต่อแชท: {exc}') from exc


def _strip_emote_tokens(text: str) -> tuple[str, list]:
    """ตัด [id:id:name] tokens ออกจาก text → (clean_text, segments)

    KICK ส่ง emote เป็น [id:id:name] ฝังในข้อความ
    Returns: (text ที่ตัด emote แล้ว, segments list สำหรับ render ภาพ)
    segments format: [{type:"text", content:"..."}, {type:"emote", url:"...", name:"..."}]
    KICK emote image URL: https://static-cdn.kick.com/images/emote/{id}/fullsize/image
    """
    if not text:
        return "", []
    segments = []
    last_pos = 0
    for m in _EMOTE_TOKEN_RE.finditer(text):
        # text ก่อน emote
        before = text[last_pos:m.start()]
        if before:
            segments.append({"type": "text", "content": before})
        # emote token → [id:id:name]
        token = m.group(0)
        inner = token.strip("[]")
        parts = inner.split(":")
        if len(parts) >= 3:
            emote_id = parts[1]
            emote_name = parts[2]
            url = f"https://static-cdn.kick.com/images/emote/{emote_id}/fullsize/image"
            segments.append({"type": "emote", "url": url, "name": emote_name})
        last_pos = m.end()
    # text หลัง emote สุดท้าย
    after = text[last_pos:]
    if after:
        segments.append({"type": "text", "content": after})
    # clean text = ตัด tokens ออก
    clean = _EMOTE_TOKEN_RE.sub("", text)
    clean = _MULTI_SPACE_RE.sub(" ", clean).strip()
    # ถ้าไม่มี emote เลย → ไม่ส่ง segments (ใช้ text ปกติ)
    has_emote = any(s.get("type") == "emote" for s in segments)
    return clean, segments if has_emote else []


def _resolve_channel(slug: str, timeout: float = 15.0) -> Optional[dict]:
    """HTTP resolve slug → channel info

    Returns: dict {chatroom_id, user_id, username} หรือ None ถ้า fail
    """
    import requests
    url = f"{KICK_API_BASE}/{slug}"
    try:
        r = requests.get(url, headers=KICK_HEADERS, timeout=timeout)
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(f"เชื่อม KICK API ไม่ได้: {exc}")
    if r.status_code == 404:
        raise RuntimeError(f"ไม่พบ channel KICK: {slug}")
    if r.status_code != 200:
        raise RuntimeError(f"KICK API error {r.status_code}: {r.text[:120]}")
    try:
        d = r.json()
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(f"KICK API: parse JSON ไม่ได้: {exc}")
    chatroom = d.get("chatroom") or {}
    chatroom_id = chatroom.get("id") or d.get("chatroom_id")
    if not chatroom_id:
        raise RuntimeError(f"KICK API: ไม่พบ chatroom_id สำหรับ {slug}")
    user = d.get("user") or {}
    livestream = d.get("livestream") or {}
    viewer_count = livestream.get("viewer_count", 0) if livestream else 0
    return {
        "chatroom_id": int(chatroom_id),
        "user_id": d.get("user_id") or user.get("id"),
        "username": user.get("username") or d.get("slug") or slug,
        "is_live": bool(d.get("livestream")),
        "viewer_count": int(viewer_count) if viewer_count else 0,
    }


# ---------------------------------------------------------------------- #
# KICK chat client
# ---------------------------------------------------------------------- #
class KickChat:
    """KICK live chat client — Pusher WebSocket (anonymous)

    รัน sync websocket loop ใน background daemon thread
    """

    def __init__(
        self,
        on_message: Callable[[ChatMessage], None],
        on_status: Optional[Callable[[str], None]] = None,
        on_error: Optional[Callable[[str], None]] = None,
        on_viewer_count: Optional[Callable[[str, int], None]] = None,
        oauth_token: str = "",
        bot_username: str = "",
        broadcaster_user_id: int = 0,
        send_as: str = "user",
    ) -> None:
        self.on_message = on_message
        self.on_status = on_status or (lambda msg: None)
        self.on_error = on_error or (lambda msg: None)
        self.on_viewer_count = on_viewer_count or (lambda plat, cnt: None)

        self._ws: Optional["websocket.WebSocket"] = None
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._is_connected = False
        self._slug = ""
        self._chatroom_id: Optional[int] = None
        self._last_viewer_poll: float = 0.0

        self.messages_read = 0

        # ★ OAuth (ส่งแชท + แก้ชื่อห้อง) — ถ้าไม่มี token = อ่านอย่างเดียว
        self._oauth_token = oauth_token or ""
        self._bot_username = (bot_username or "").lower()
        self._broadcaster_user_id = int(broadcaster_user_id or 0)
        # ★ ส่งเป็นบัญชีของเราเสมอ (บัญชีเรา = บอท) — โหมด bot ทางการยังติด 500
        self._send_as = "user"
        # ★ hooks สำหรับ app.py: auto-refresh token เมื่อหมดอายุ (401)
        self._refresh_token = ""           # refresh token (set จาก app.py)
        self._on_token_refreshed = None    # callback(new_token, new_refresh) → save settings
        self._send_lock = threading.Lock()

    # ------------------------------------------------------------------ #
    # ★ Send capability (OAuth)
    # ------------------------------------------------------------------ #
    @property
    def can_send(self) -> bool:
        """ส่งแชทได้ไหม — ต้องมี OAuth token"""
        return bool(self._oauth_token)

    @property
    def bot_username(self) -> str:
        return self._bot_username

    def set_oauth(self, token: str, broadcaster_user_id: int = 0, bot_username: str = "") -> None:
        """อัปเดต token หลัง refresh/login ใหม่"""
        self._oauth_token = token or ""
        if broadcaster_user_id:
            self._broadcaster_user_id = int(broadcaster_user_id)
        if bot_username:
            self._bot_username = bot_username.lower()

    def _api_headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self._oauth_token}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    def _try_refresh_token(self) -> bool:
        """token หมดอายุ (401) → ลอง refresh ผ่าน kick_oauth
        Returns True ถ้าได้ token ใหม่
        """
        if not self._refresh_token:
            return False
        try:
            from kick_oauth import refresh_access_token
            result = refresh_access_token(self._refresh_token)
            if result and result.get("access_token"):
                self._oauth_token = result["access_token"]
                self._refresh_token = result.get("refresh_token") or self._refresh_token
                if self._on_token_refreshed:
                    try:
                        self._on_token_refreshed(self._oauth_token, self._refresh_token)
                    except Exception:
                        pass
                return True
        except Exception as exc:  # noqa: BLE001
            self.on_error(f"KICK token refresh ไม่สำเร็จ: {exc}")
        return False

    def send_message(self, text: str) -> bool:
        """★ ส่งข้อความเข้าแชท KICK ของตัวเอง

        POST https://api.kick.com/public/v1/chat (scope: chat:write)
        - type="bot"  → ขึ้นเป็นบอท (ไม่ต้องระบุ broadcaster_user_id)
        - type="user" → ขึ้นเป็นบัญชีเจ้าของ (ต้องมี broadcaster_user_id)
        Returns True ถ้าส่งสำเร็จ
        """
        import requests as _requests
        if not self._oauth_token or not text:
            return False
        content = text.strip()[:500]  # KICK limit 500 ตัวอักษร
        with self._send_lock:
            for attempt in range(3):
                body = {"content": content, "type": self._send_as}
                if self._send_as == "user":
                    if not self._broadcaster_user_id:
                        self.on_error("KICK: ไม่มี broadcaster_user_id — ล็อกอินใหม่อีกครั้ง")
                        return False
                    body["broadcaster_user_id"] = self._broadcaster_user_id
                try:
                    r = _requests.post(
                        "https://api.kick.com/public/v1/chat",
                        headers=self._api_headers(),
                        json=body,
                        timeout=10,
                    )
                except Exception as exc:  # noqa: BLE001
                    self.on_error(f"KICK ส่งไม่สำเร็จ: {exc}")
                    return False
                if r.status_code in (200, 201):
                    try:
                        data = r.json()
                        result = data.get("data", data) if isinstance(data, dict) else {}
                        return bool(result.get("is_sent", True)) if isinstance(result, dict) else True
                    except Exception:
                        return True
                if r.status_code == 401 and attempt < 2:
                    # ★ token หมดอายุ → refresh แล้วลองใหม่
                    if self._try_refresh_token():
                        continue
                    self.on_error("KICK: token หมดอายุ — กดเชื่อมต่อ KICK ใหม่ในการตั้งค่า")
                    return False
                if r.status_code == 429:
                    self.on_error("KICK: ส่งเร็วเกินไป (rate limit) — รอสักครู่")
                    return False
                self.on_error(f"KICK ส่งไม่สำเร็จ (HTTP {r.status_code}): {r.text[:120]}")
                return False
        return False

    def update_stream_title(self, title: str) -> bool:
        """★ แก้ชื่อห้อง (stream title) ของช่องตัวเอง

        PATCH https://api.kick.com/public/v1/channels (scope: channel:write)
        Returns True ถ้าสำเร็จ
        """
        import requests as _requests
        if not self._oauth_token or not (title or "").strip():
            return False
        with self._send_lock:
            for attempt in range(2):
                try:
                    r = _requests.patch(
                        "https://api.kick.com/public/v1/channels",
                        headers=self._api_headers(),
                        json={"stream_title": title.strip()},
                        timeout=10,
                    )
                except Exception as exc:  # noqa: BLE001
                    self.on_error(f"KICK แก้ชื่อห้องไม่สำเร็จ: {exc}")
                    return False
                if r.status_code in (200, 204):
                    return True
                if r.status_code == 401 and attempt == 0:
                    if self._try_refresh_token():
                        continue
                    return False
                self.on_error(f"KICK แก้ชื่อห้องไม่สำเร็จ (HTTP {r.status_code}): {r.text[:120]}")
                return False
        return False

    # ------------------------------------------------------------------ #
    # Availability
    # ------------------------------------------------------------------ #
    @staticmethod
    def is_available() -> bool:
        return _WS_AVAILABLE

    @staticmethod
    def import_error() -> Optional[str]:
        return _WS_IMPORT_ERROR

    @property
    def is_connected(self) -> bool:
        return self._is_connected

    # ------------------------------------------------------------------ #
    # Connection
    # ------------------------------------------------------------------ #
    def connect(self, slug: str) -> bool:
        """เชื่อมต่อ KICK — slug = username (เช่น 'trainwreckstv')

        Returns True ถ้า resolve สำเร็จ + เริ่ม WS loop
        """
        if not _WS_AVAILABLE:
            self.on_error(
                f"ไม่ได้ติดตั้ง websocket-client: {_WS_IMPORT_ERROR}\n"
                "ติดตั้งด้วย: pip install websocket-client"
            )
            return False

        # normalize slug — เอา URL ออก, เอา @ ออก
        slug = (slug or "").strip().lstrip("@").strip()
        if "/" in slug:
            slug = slug.rstrip("/").split("/")[-1]
        if not slug:
            self.on_error("กรุณาใส่ชื่อ KICK channel (slug)")
            return False
        if self._is_connected:
            self.on_error("เชื่อมต่อ KICK อยู่แล้ว — กด Disconnect ก่อน")
            return False

        # resolve slug → chatroom_id
        try:
            info = _resolve_channel(slug)
        except RuntimeError as exc:
            self.on_error(str(exc))
            return False
        self._slug = slug
        self._chatroom_id = info["chatroom_id"]
        self._broadcaster_user_id = int(info.get("user_id") or 0)
        self._stop_event.clear()
        # emit initial viewer count (จาก resolve response)
        vc = info.get("viewer_count", 0)
        if vc:
            self.on_viewer_count("kick", vc)

        # เริ่ม WS loop ใน background thread
        self._thread = threading.Thread(
            target=self._ws_loop, name="KickWSReader", daemon=True,
        )
        self._thread.start()
        return True

    def disconnect(self) -> None:
        """ยกเลิกการเชื่อมต่อ"""
        self._stop_event.set()
        self._is_connected = False
        if self._ws is not None:
            try:
                self._ws.close()
            except Exception:
                pass
            self._ws = None
        if self._thread is not None and self._thread.is_alive():
            self._thread.join(timeout=4)
        self._thread = None
        self.on_status("⚪ ยกเลิกการเชื่อมต่อ KICK")

    # ------------------------------------------------------------------ #
    # WebSocket loop (background thread)
    # ------------------------------------------------------------------ #
    def _ws_loop(self) -> None:
        """รัน WS connect + read loop จนกว่าจะ disconnect"""
        assert websocket is not None
        chatroom_id = self._chatroom_id
        try:
            ws = websocket.WebSocket()
            ws.settimeout(5.0)  # short timeout → ตอบ _stop_event ได้
            ws.connect(_realtime_pusher_url())
            self._ws = ws
            hello = json.loads(ws.recv())
            if hello.get('event') != 'pusher:connection_established':
                detail = hello.get('data') or hello.get('event') or 'ไม่มีคำตอบ'
                raise RuntimeError(f'KICK ไม่ยืนยันการเชื่อมต่อ: {detail}')
        except Exception as exc:  # noqa: BLE001
            if not self._stop_event.is_set():
                self.on_error(f"KICK WS เชื่อมต่อไม่ได้: {exc}")
            self._is_connected = False
            try: ws.close()
            except Exception: pass
            return

        # subscribe to chatroom channel (anonymous — auth ว่าง)
        channel = f"chatrooms.{chatroom_id}.v2"
        try:
            ws.send(json.dumps({
                "event": "pusher:subscribe",
                "data": {"auth": "", "channel": channel},
            }))
            deadline = time.monotonic() + 10
            subscribed = False
            while time.monotonic() < deadline and not self._stop_event.is_set():
                frame = json.loads(ws.recv())
                event = frame.get('event')
                if event == 'pusher:ping':
                    ws.send(json.dumps({'event': 'pusher:pong', 'data': {}}))
                elif event == 'pusher_internal:subscription_succeeded' and frame.get('channel') == channel:
                    subscribed = True
                    break
                elif event in ('pusher:error', 'pusher:subscription_error'):
                    raise RuntimeError(str(frame.get('data') or event))
            if not subscribed:
                raise RuntimeError('ไม่ได้รับการยืนยันเข้าห้องแชท KICK')
        except Exception as exc:  # noqa: BLE001
            if not self._stop_event.is_set():
                self.on_error(f"KICK subscribe ไม่ได้: {exc}")
            self._is_connected = False
            try: ws.close()
            except Exception: pass
            return

        self._is_connected = True
        self.on_status(f"✅ เชื่อมต่อ KICK @{self._slug}")

        # read loop
        while not self._stop_event.is_set():
            try:
                raw = ws.recv()
            except Exception as exc:  # noqa: BLE001
                # timeout → loop ใหม่ (เช็ค _stop_event + poll viewer count)
                if "timed out" in str(exc).lower():
                    self._poll_viewer_count()
                    continue
                if not self._stop_event.is_set():
                    self.on_error(f"KICK WS หลุด: {exc}")
                break
            if not raw:
                continue
            try:
                self._handle_raw(raw)
            except Exception as exc:  # noqa: BLE001
                # ไม่ drop connection เพราะ parse error ตัวเดียว
                if not self._stop_event.is_set():
                    pass  # silent — กัน log spam

        self._is_connected = False
        try:
            ws.close()
        except Exception:
            pass

    def _poll_viewer_count(self) -> None:
        """re-poll KICK resolve endpoint เพื่ออัปเดต viewer count (ทุก ~60s)"""
        if self._stop_event.is_set() or not self._slug:
            return
        import time as _time
        now = _time.time()
        if now - self._last_viewer_poll < 55:
            return
        try:
            info = _resolve_channel(self._slug)
            vc = info.get("viewer_count", 0)
            self.on_viewer_count("kick", vc)
        except Exception:
            pass
        self._last_viewer_poll = now

    # ------------------------------------------------------------------ #
    # Event dispatch
    # ------------------------------------------------------------------ #
    def _handle_raw(self, raw: str) -> None:
        """parse Pusher message → dispatch event"""
        try:
            envelope = json.loads(raw)
        except Exception:
            return
        event = envelope.get("event", "")
        channel = envelope.get("channel", "")
        data_raw = envelope.get("data", "")

        # keepalive
        if event == "pusher:ping":
            try:
                self._ws.send(json.dumps({"event": "pusher:pong", "data": {}}))
            except Exception:
                pass
            return
        if event == "pusher:error":
            err = data_raw if isinstance(data_raw, dict) else {}
            msg = err.get("message", "unknown pusher error")
            if not self._stop_event.is_set():
                self.on_error(f"KICK Pusher error: {msg}")
            return
        # subscription ack — ignore
        if event in (
            "pusher:connection_established",
            "pusher_internal:subscription_succeeded",
        ):
            return

        # parse data (Pusher ส่ง data เป็น JSON string ในหลายกรณี)
        data = data_raw
        if isinstance(data, str) and data:
            try:
                data = json.loads(data)
            except Exception:
                pass
        if not isinstance(data, dict):
            return

        # ── chat message ──
        if event in ("AppMessageEvent", "App\\Events\\ChatMessageEvent", "message"):
            self._handle_chat(data)
        # ── gifted subscription ──
        elif event in (
            "App\\Events\\GiftedSubscriptionsEvent",
            "GiftedSubscriptionsEvent",
        ):
            self._handle_gifted_sub(data, is_gifter=True)
        elif event in (
            "App\\Events\\LuckyUsersWhoGotGiftSubscriptionsEvent",
            "LuckyUsersWhoGotGiftSubscriptionsEvent",
        ):
            self._handle_gifted_sub(data, is_gifter=False)
        # ── สมัครซับ / ซับต่อ (months) ──
        elif event in ("App\\Events\\SubscriptionEvent", "SubscriptionEvent"):
            self._handle_subscription(data)
        # ── KICKs gifted (ทิปของ KICK — แนบข้อความได้) ──
        elif event in ("App\\Events\\KicksGifted", "KicksGifted",
                       "App\\Events\\KicksGiftedEvent", "KicksGiftedEvent"):
            self._handle_kicks_gifted(data)
        # ── stream status (optional — ignore เพื่อลด noise) ──
        elif event in (
            "App\\Events\\StreamerIsLive",
            "StreamerIsLive",
            "App\\Events\\StopStreamBroadcast",
            "StopStreamBroadcast",
        ):
            pass
        # อื่นๆ — ignore (PinMessage, UserBannedFromChannel, etc.)

    def _handle_chat(self, data: dict) -> None:
        """KICK chat message → ChatMessage(event="message")"""
        content = data.get("content", "") or ""
        author_data = data.get("author") or data.get("sender") or {}
        author = (
            author_data.get("username")
            or author_data.get("name")
            or data.get("username")
            or "?"
        )
        # ★ ข้อความของบัญชีที่ล็อกอิน (ส่งผ่านโปรแกรม หรือพิมพ์บนเว็บ KICK) → ส่งขึ้นไป
        #   ให้ app.py แยกกรณีเหมือน Twitch (echo โปรแกรม = ซ่อน / พิมพ์บนเว็บ = แสดง
        #   แต่ไม่อ่าน TTS) — เดิมดักทิ้งหมดฝั่งนี้ = พิมพ์บน KICK แล้วหายจากโปรแกรม
        clean_text, segments = _strip_emote_tokens(content)
        kick_avatar = (
            author_data.get("profile_thumb")
            or author_data.get("profile_pic")
            or author_data.get("profile_image")
            or (author_data.get("identity") or {}).get("profile_pic")
            or ""
        )
        self.messages_read += 1
        self.on_message(
            ChatMessage(
                platform="kick",
                author=author,
                text=clean_text,
                event="message",
                extra={
                    "kick_user_id": author_data.get("id"),
                    "avatar_url": kick_avatar,
                    "segments": segments if segments else None,
                    "source_id": data.get("id") or None,   # KICK message id: central read-once rule
                },
            )
        )

    def _handle_subscription(self, data: dict) -> None:
        """KICK SubscriptionEvent → ซับใหม่/ซับต่อ (months = เดือนที่ซับ) — KICK ไม่มีช่องข้อความแนบ"""
        user = data.get("user") if isinstance(data.get("user"), dict) else {}
        author = data.get("username") or user.get("username") or user.get("name") or "?"
        try:
            months = int(data.get("months") or 1)
        except (TypeError, ValueError):
            months = 1
        event = "resub" if months > 1 else "sub"
        self.messages_read += 1
        self.on_message(
            ChatMessage(
                platform="kick", author=author, text="", event=event,
                system_text=f"ซับ {months} เดือน" if months > 1 else "สมัครซับ",
                extra={"detail": {"months": months}},
            )
        )

    def _handle_kicks_gifted(self, data: dict) -> None:
        """KICK KicksGifted → ทิป (KICKs) พร้อมข้อความที่ผู้ส่งแนบ

        รูปแบบตาม webhook kicks.gifted ของ KICK: {sender:{username}, gift:{amount, name, tier, message}}
        (รูปแบบจริงบน pusher ยังไม่ได้ยืนยัน จึงอ่านแบบยืดหยุ่น: message/amount อยู่ชั้นบนหรือในตัว gift ก็ได้)
        """
        gift = data.get("gift") if isinstance(data.get("gift"), dict) else {}
        sender = data.get("sender") or data.get("user") or {}
        if not isinstance(sender, dict):
            sender = {"username": str(sender)}
        author = sender.get("username") or sender.get("name") or data.get("username") or "?"
        message = data.get("message") or gift.get("message") or ""
        raw_amt = gift.get("amount", data.get("amount", data.get("kicks")))
        try:
            amount = int(raw_amt) if raw_amt is not None else None
        except (TypeError, ValueError):
            amount = None
        self.messages_read += 1
        self.on_message(
            ChatMessage(
                platform="kick", author=author, text=str(message), event="bits", amount=amount,
                system_text=f"ส่ง {amount:,} KICKs" if amount else "ส่ง KICKs",
                extra={"detail": {"kind": "kicks", "gift_name": gift.get("name", ""),
                                  "tier": gift.get("tier", "")}},
            )
        )

    def _handle_gifted_sub(self, data: dict, is_gifter: bool) -> None:
        """KICK gifted subscription → ChatMessage(event="subgift")

        is_gifter=True = คนที่มอบ sub (GiftedSubscriptionsEvent)
        is_gifter=False = คนที่รับ sub (LuckyUsersWhoGotGiftSubscriptionsEvent)
        """
        # structure ประมาณ: {gifter_user: {username}, gifted_user: {...}, ...}
        gifter = data.get("gifter") or data.get("gifter_user") or {}
        gifted = data.get("gifted") or data.get("gifted_user") or data.get("user") or {}
        # ★ รูปแบบที่ KICK ส่งจริงมักเป็น gifter_username (string) + gifted_usernames (list) — รองรับทั้งสองแบบ
        if not isinstance(gifter, dict):
            gifter = {"username": str(gifter)}
        if not isinstance(gifted, dict):
            gifted = {"username": str(gifted)}
        gifter_name = data.get("gifter_username") or gifter.get("username") or gifter.get("name") or ""
        recipients = data.get("gifted_usernames")
        if not isinstance(recipients, (list, tuple)):
            one = gifted.get("username") or gifted.get("name") or ""
            recipients = [one] if one else []
        recipients = [str(x) for x in recipients if x]
        count = data.get("gifted_amount") or data.get("quantity") or (len(recipients) or 1)
        try:
            count = int(count)
        except (TypeError, ValueError):
            count = len(recipients) or 1
        if is_gifter:
            author = gifter_name or "?"
            sys_text = "มอบ KICK Sub"
            if count > 1:
                sys_text = f"มอบ KICK Sub ×{count}"
        else:
            author = (recipients[0] if recipients else "") or gifted.get("username") or gifted.get("name") or "?"
            sys_text = "ได้รับ KICK Sub"
        display = f"🎁 {sys_text}"
        self.messages_read += 1
        self.on_message(
            ChatMessage(
                platform="kick",
                author=author,
                text=display,
                event="subgift",
                system_text=sys_text,
                extra={
                    "kick_user_id": (gifter if is_gifter else gifted).get("id"),
                    "is_gifter": is_gifter,
                    "detail": {"is_gifter": is_gifter, "recipients": recipients, "count": count,
                               "gifter": gifter_name},
                },
            )
        )


# ---------------------------------------------------------------------- #
# Smoke test
# ---------------------------------------------------------------------- #
if __name__ == "__main__":
    import sys

    if not _WS_AVAILABLE:
        print(f"websocket-client ไม่พร้อม: {_WS_IMPORT_ERROR}")
        print("ติดตั้งด้วย: pip install websocket-client")
        sys.exit(1)

    if len(sys.argv) < 2:
        print("Usage: python chat_kick.py <slug> [seconds]")
        print("Example: python chat_kick.py trainwreckstv 20")
        sys.exit(1)

    slug = sys.argv[1]
    duration = int(sys.argv[2]) if len(sys.argv) > 2 else 20

    def cb(msg: ChatMessage) -> None:
        amount_str = f" [{msg.amount}]" if msg.amount else ""
        sys_str = f"  ({msg.system_text})" if msg.system_text else ""
        print(f"[{msg.event}] {msg.author}{amount_str}: {msg.text}{sys_str}")

    def status(msg: str) -> None:
        print(f">> {msg}")

    client = KickChat(on_message=cb, on_status=status, on_error=status)
    if client.connect(slug):
        time.sleep(duration)
        client.disconnect()
        print(f">> read {client.messages_read} messages")
